function results = main_bcmkc(config)
root = fileparts(mfilename('fullpath'));
addpath(fullfile(root,'bcmkc'),fullfile(root,'ClusteringEvaluation'),fullfile(root,'utils'));
state = rng;
restoreState = onCleanup(@() rng(state));
if nargin < 1 || ~isstruct(config) || ~isfield(config,'dataset_dir')
    error('BCMKC:InputRequired','Provide config.dataset_dir for external input data.');
end
if ~isfield(config,'datasets')
    config.datasets = {'bbcsport','CUB','proteinFold','Reuters','Scene_15', ...
        'Fashion_3V','ALOI-100','YouTubeFace10_4Views','NoisyMNIST','Winnipeg1_fea'};
end
if ischar(config.datasets) || isstring(config.datasets)
    config.datasets = cellstr(config.datasets);
end
if ~isfield(config,'num_runs'), config.num_runs = 5; end
if ~isfield(config,'options'), config.options = struct(); end
opts = merge_options(bcmkc_default_options(),config.options);
opts.verbose = false;
schedule = bcmkc_seed_schedule(config.num_runs,opts);
results = struct([]);
for d = 1:numel(config.datasets)
    name = char(config.datasets{d});
    inputFile = fullfile(config.dataset_dir,[name '.mat']);
    if ~isfile(inputFile), error('BCMKC:DatasetMissing','Requested dataset is unavailable.'); end
    data = load(inputFile,'X','Y');
    if ~isfield(data,'X') || ~isfield(data,'Y')
        error('BCMKC:DatasetFormat','Input must contain X and Y.');
    end
    X = data.X(:); Y = relabel_consecutive(data.Y);
    k = predefined_cluster_count(name,config,d);
    if ~iscell(X) || isempty(X) || numel(Y) ~= size(X{1},1) || ...
            ~isscalar(k) || k < 1 || k >= size(X{1},1) || k ~= floor(k)
        error('BCMKC:DatasetFormat','Invalid aligned views, labels, or cluster count.');
    end
    [datasetOpts,~] = bcmkc_adapt_options_for_dataset(opts,size(X{1},1), ...
        numel(X),k,cellfun(@(z) size(z,2),X));
    landmarkBudget = 300;
    if strcmpi(name,'YouTubeFace10_4Views')
        landmarkBudget = 150;
    elseif strcmpi(name,'Winnipeg1_fea')
        landmarkBudget = 100;
    end
    datasetOpts.num_landmarks = min(landmarkBudget,size(X{1},1));
    datasetOpts.paper.base_landmarks = datasetOpts.num_landmarks;
    strategy = bcmkc_resolve_paper_strategy(size(X{1},1),numel(X),k, ...
        min(datasetOpts.paper.base_landmarks,size(X{1},1)),datasetOpts, ...
        cellfun(@(z) size(z,2),X));
    if strcmp(strategy,'paired_image_hog')
        hogRank = max(k,round(datasetOpts.paper.paired_hog_rank_multiplier*k));
        hogRank = min([hogRank,size(X{1},1)-1,datasetOpts.num_landmarks]);
        if ~isempty(datasetOpts.spectral.max_rank)
            hogRank = min(hogRank,floor(datasetOpts.spectral.max_rank));
        end
        [hogScores,hogInfo] = build_paired_hog_embedding(X,hogRank,datasetOpts);
        datasetOpts.paper.paired_hog_precomputed = struct( ...
            'scores',hogScores,'info',hogInfo,'sample_count',size(X{1},1), ...
            'feature_dimension',size(X{1},2),'rank',hogRank);
    end
    partitionValues = zeros(config.num_runs,4);
    protocolValues = zeros(config.num_runs,4);
    names = {'ACC','NMI','Purity','ARI'};
    for run = 1:config.num_runs
        runOpts = apply_run_seeds(datasetOpts,schedule(run));
        runOpts.num_landmarks = min(datasetOpts.num_landmarks,size(X{1},1));
        fit = bcmkc_fit(X,k,runOpts);
        metrics = clustering_metrics(Y,fit.labels);
        embedding = fit.U;
        if ~isempty(fit.paper_protocol_embedding), embedding = fit.paper_protocol_embedding; end
        protocol = paper_protocol_metrics(embedding,Y,k, ...
            runOpts.paper.protocol_outer_iterations,runOpts.paper.protocol_replicates, ...
            schedule(run).protocol_seed);
        for j = 1:4
            partitionValues(run,j) = metrics.(names{j});
            protocolValues(run,j) = protocol.(names{j});
        end
    end
    item.dataset = name;
    item.single_partition = summarize_values(partitionValues,names);
    item.paper_protocol = summarize_values(protocolValues,names);
    if d == 1, results = item; else, results(d) = item; end
end
end

function summary = summarize_values(values,names)
if any(~isfinite(values(:)))
    error('BCMKC:NonfiniteMetrics','A complete run returned a nonfinite metric.');
end
for j = 1:numel(names)
    summary.(names{j}) = struct('mean',mean(values(:,j)), ...
        'std',std(values(:,j),0),'runs',values(:,j));
end
end

function optsRun = apply_run_seeds(opts,seeds)
optsRun = opts;
optsRun.seed = seeds.model_seed;
optsRun.paper.base_seed = seeds.paper_base_seed;
optsRun.paper.bagging_seeds = seeds.paper_bagging_seeds;
optsRun.paper.overcomplete_seeds = seeds.paper_overcomplete_seeds;
optsRun.paper.protocol_seed = seeds.protocol_seed;
optsRun.discretizer.seed = seeds.discretizer_seed;
end


function k = predefined_cluster_count(dataName,config,datasetIndex)
switch lower(dataName)
    case 'bbcsport'
        k = 5;
    case 'cub'
        k = 10;
    case {'proteinfold','pfold'}
        k = 27;
    case 'reuters'
        k = 6;
    case {'scene_15','scene15'}
        k = 15;
    case {'fashion_3v','fashion'}
        k = 10;
    case {'aloi','aloi_100','aloi-100'}
        k = 100;
    case {'ytf10','youtubeface10_4views'}
        k = 10;
    case {'nmnist','noisymnist'}
        k = 10;
    case {'winnipeg','winnipeg1_fea'}
        k = 7;
    otherwise
        if ~isfield(config,'cluster_counts') || isempty(config.cluster_counts)
            error('BCMKC:ClusterCountRequired', ...
                ['Unknown dataset %s requires config.cluster_counts; ', ...
                'ground-truth labels are never used to choose k.'],dataName);
        end
        counts = config.cluster_counts;
        if isa(counts,'containers.Map')
            if ~isKey(counts,dataName)
                error('BCMKC:ClusterCountRequired', ...
                    'config.cluster_counts has no entry for %s.',dataName);
            end
            k = counts(dataName);
        elseif isstruct(counts)
            field = matlab.lang.makeValidName(dataName);
            if ~isfield(counts,field)
                error('BCMKC:ClusterCountRequired', ...
                    'config.cluster_counts has no field for %s.',dataName);
            end
            k = counts.(field);
        elseif isnumeric(counts) && isvector(counts) && ...
                numel(counts) == numel(config.datasets)
            k = counts(datasetIndex);
        elseif isnumeric(counts) && isscalar(counts) && ...
                isscalar(config.datasets)
            k = counts;
        else
            error('BCMKC:InvalidClusterCounts', ...
                ['cluster_counts must be a dataset-keyed struct/map or ', ...
                'one numeric value per configured dataset.']);
        end
end
end
