function P = create_kernel(A, C)
num = size(A, 1);
anchor_num = size(C, 1);

row_norms = sum(A .* A,2);
anchor_norms = sum(C .* C,2);
sum_distances = anchor_num*sum(row_norms) + num*sum(anchor_norms) ...
    - 2*(sum(A,1)*sum(C,1)');
delta = 2*sum_distances/(num*anchor_num);
if ~isfinite(delta) || delta <= 0
    delta = eps(class(A));
end

block_rows = max(1,min(num,floor(8e6/max(anchor_num,1))));
P = zeros(num,anchor_num,'like',A);
for first = 1:block_rows:num
    last = min(num,first+block_rows-1);
    rows = first:last;
    dmatrix = bsxfun(@plus,row_norms(rows),anchor_norms') ...
        - 2*(A(rows,:)*C');
    P(rows,:) = exp(-dmatrix/delta);
end
end
