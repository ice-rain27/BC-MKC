function Y = row_normalize(X)

denom = sqrt(sum(X.^2,2));
denom(denom < eps) = 1;
Y = bsxfun(@rdivide,X,denom);
end

