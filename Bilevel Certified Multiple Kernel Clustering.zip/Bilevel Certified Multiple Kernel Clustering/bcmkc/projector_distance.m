function value = projector_distance(U,V)

k = size(U,2);
overlap = norm(U'*V,'fro')^2;
value = sqrt(max(0,2*k-2*overlap));
end

