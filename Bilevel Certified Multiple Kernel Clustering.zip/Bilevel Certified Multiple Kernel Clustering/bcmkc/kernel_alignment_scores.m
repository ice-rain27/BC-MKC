function scores = kernel_alignment_scores(factors,U)

m = numel(factors);
scores = zeros(m,1);
for v = 1:m
    scores(v) = norm(factors{v}'*U,'fro')^2;
end
end
