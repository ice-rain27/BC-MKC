function [rankResolved,info] = bcmkc_resolve_spectral_rank( ...
    clusterCount,sampleCount,factors,opts)

if ~(isscalar(clusterCount) && isfinite(clusterCount) && ...
        clusterCount == round(clusterCount) && clusterCount >= 1 && ...
        clusterCount < sampleCount)
    error('BCMKC:InvalidClusterCount', ...
        'clusterCount must be an integer in [1, sampleCount-1].');
end
multiplier = opts.spectral.rank_multiplier;
if ~(isscalar(multiplier) && isfinite(multiplier) && multiplier >= 1)
    error('BCMKC:InvalidSpectralMultiplier', ...
        'spectral.rank_multiplier must be a finite scalar at least one.');
end
rankRequested = max(clusterCount,round(multiplier*clusterCount));

rankLimit = sampleCount-1;
if isfield(opts.spectral,'max_rank') && ~isempty(opts.spectral.max_rank)
    maxRank = opts.spectral.max_rank;
    if ~(isscalar(maxRank) && isfinite(maxRank) && maxRank >= clusterCount)
        error('BCMKC:InvalidSpectralRankCap', ...
            'spectral.max_rank must be empty or at least clusterCount.');
    end
    rankLimit = min(rankLimit,floor(maxRank));
end
if opts.kernel.projector_compression
    factorRanks = cellfun(@(value) size(value,2),factors);
    rankLimit = min(rankLimit,min(factorRanks));
else
    factorRanks = cellfun(@(value) size(value,2),factors);
end
rankResolved = min(rankRequested,rankLimit);
if rankResolved < clusterCount
    error('BCMKC:InsufficientSpectralRank', ...
        ['The available factor dimension (%d) is smaller than the ', ...
        'cluster count (%d).'],rankResolved,clusterCount);
end

info.cluster_count = clusterCount;
info.multiplier = multiplier;
info.requested_rank = rankRequested;
info.resolved_rank = rankResolved;
info.sample_rank_limit = sampleCount-1;
info.factor_ranks = factorRanks(:);
info.was_clipped = rankResolved < rankRequested;
info.uses_ground_truth = false;
end
