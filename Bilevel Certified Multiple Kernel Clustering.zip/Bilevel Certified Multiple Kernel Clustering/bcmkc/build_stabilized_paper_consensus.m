function [factor,info] = build_stabilized_paper_consensus( ...
    X,k,opts,spectralRank)

if nargin < 4 || isempty(spectralRank)
    spectralRank = k;
end
X = X(:);
n = size(X{1},1);
viewCount = numel(X);
if ~(isscalar(spectralRank) && spectralRank == round(spectralRank) && ...
        spectralRank >= k && spectralRank < n)
    error('BCMKC:InvalidSpectralRank', ...
        'spectralRank must be an integer in [k,n-1].');
end

baseAnchors = min(opts.paper.base_landmarks,n);
if baseAnchors < k
    error('BCMKC:InsufficientPaperAnchors', ...
        'paper.base_landmarks must be at least the cluster count.');
end
baseSeed = opts.paper.base_seed;
strategy = lower(char(opts.paper.strategy));
automatic = strcmp(strategy,'auto');
if automatic
    strategy = bcmkc_resolve_paper_strategy( ...
        n,viewCount,k,baseAnchors,opts,cellfun(@(z) size(z,2),X));
end

if any(strcmp(strategy,{'hierarchical_stability', ...
        'robust_direct_barycenter','paired_image_hog'}))
    baseLandmarks = [];
else
    [baseKH,baseLandmarks] = paper_build_cross_kernels( ...
        X,baseAnchors,baseSeed);
end

switch strategy
    case 'paired_image_hog'
        [hogScores,hogInfo] = build_paired_hog_embedding( ...
            X,spectralRank,opts);
        [robustU,~] = qr(hogScores,0);
        clear hogScores
        components = reshape(single(robustU),n,spectralRank,1);
        componentNames = {'paired_average_hog_pca'};
        weights = 1;
        bankLandmarks = cell(0,1);
        anchors = [];
        seeds = opts.paper.paired_hog_pca_seed;
        orders = 1:viewCount;
        recommendedPrior = opts.paper.prior_paired_hog;
        scalable = true;
        barycenterGap = hogInfo.normalized_gap;
        robustDetails = hogInfo;
        robustDetails.selection_signal = ...
            'two aligned square-image views; fixed structural descriptor';

    case 'robust_direct_barycenter'
        [robustViews,transformInfo] = robust_asinh_views(X);
        [robustKH,robustLandmarks] = paper_build_cross_kernels( ...
            robustViews,baseAnchors,baseSeed);
        components = zeros(n,spectralRank,viewCount,'single');
        singularValues = cell(viewCount,1);
        for v = 1:viewCount
            [Uv,values] = paper_truncated_left_space( ...
                robustKH(:,:,v),spectralRank);
            components(:,:,v) = single(Uv);
            singularValues{v} = values;
        end
        weights = ones(viewCount,1)/viewCount;
        [robustU,barycenterGap] = paper_subspace_barycenter( ...
            double(components),weights,spectralRank);
        componentNames = arrayfun(@(v) sprintf( ...
            'robust_asinh_direct_view_%d',v),(1:viewCount)', ...
            'UniformOutput',false);
        bankLandmarks = arrayfun(@(v) robustLandmarks(v,:), ...
            (1:viewCount)','UniformOutput',false);
        anchors = baseAnchors;
        seeds = baseSeed;
        orders = 1:viewCount;
        recommendedPrior = opts.paper.prior_robust_direct;
        scalable = true;
        robustDetails.transform = transformInfo;
        robustDetails.singular_values = singularValues;
        robustDetails.selection_signal = ...
            'known cluster count threshold; symmetric label-free transform';
        clear robustKH robustViews

    case 'trimmed_cross_fusion'
        perView = zeros(n,spectralRank,viewCount,'single');
        for v = 1:viewCount
            perView(:,:,v) = single(paper_truncated_left_space( ...
                baseKH(:,:,v),spectralRank));
        end
        [agreement,centrality] = subspace_agreement( ...
            double(perView),spectralRank);
        offDiagonal = agreement(~eye(viewCount));
        agreementThreshold = median(offDiagonal);
        selectedViews = find(centrality >= agreementThreshold);
        if numel(selectedViews) < 2
            [~,ranked] = sort(centrality,'descend');
            selectedViews = sort(ranked(1:min(3,viewCount)));
        end
        crossRows = zeros(n,baseAnchors*numel(selectedViews),'single');
        for q = 1:numel(selectedViews)
            v = selectedViews(q);
            block = single(baseKH(:,:,v));
            block = bsxfun(@rdivide,block, ...
                max(sqrt(sum(block.^2,2)),eps));
            columns = (q-1)*baseAnchors+(1:baseAnchors);
            crossRows(:,columns) = block;
        end
        clear baseKH
        [robustU,spectrum] = paper_truncated_left_space( ...
            crossRows,spectralRank+1);
        if size(robustU,2) > spectralRank
            robustU = robustU(:,1:spectralRank);
        end
        if numel(spectrum) > spectralRank
            barycenterGap = spectrum(spectralRank)^2- ...
                spectrum(spectralRank+1)^2;
        else
            barycenterGap = inf;
        end
        components = perView;
        componentNames = arrayfun(@(v) sprintf('direct_view_%d',v), ...
            (1:viewCount)','UniformOutput',false);
        weights = zeros(viewCount,1);
        weights(selectedViews) = 1/numel(selectedViews);
        bankLandmarks = arrayfun(@(v) baseLandmarks(v,:), ...
            (1:viewCount)','UniformOutput',false);
        anchors = baseAnchors;
        seeds = baseSeed;
        orders = 1:viewCount;
        recommendedPrior = opts.paper.prior_trimmed_cross;
        scalable = true;
        robustDetails.agreement = agreement;
        robustDetails.centrality = centrality;
        robustDetails.agreement_threshold = agreementThreshold;
        robustDetails.selected_views = selectedViews(:)';
        robustDetails.selection_signal = ...
            'label-free top-r subspace agreement';
        clear crossRows perView

    case 'hierarchical_stability'
        anchors = anchor_schedule(baseAnchors, ...
            opts.paper.hierarchical_anchor_ratios,n,spectralRank);
        [~,hierarchical] = build_hierarchical_stable_consensus( ...
            X,k,spectralRank,anchors,baseSeed,opts);
        robustU = hierarchical.robust_embedding;
        barycenterGap = hierarchical.barycenter_gap;
        components = hierarchical.components;
        componentNames = hierarchical.component_names;
        bankLandmarks = hierarchical.landmarks;
        weights = hierarchical.component_weights;
        seeds = baseSeed;
        orders = 1:viewCount;
        recommendedPrior = opts.paper.prior_hierarchical;
        scalable = true;

    case 'overcomplete_multiscale'
        anchors = anchor_schedule(baseAnchors, ...
            opts.paper.overcomplete_anchor_ratios,n,spectralRank);
        seeds = opts.paper.overcomplete_seeds(:)';
        orders = paper_view_orders(viewCount,opts.paper.max_orders);
        [components,componentNames,bankLandmarks] = ...
            build_paper_component_bank(X,anchors,seeds,orders,spectralRank);
        weights = ones(size(components,3),1)/size(components,3);
        [robustU,barycenterGap] = paper_subspace_barycenter( ...
            components,weights,spectralRank);
        recommendedPrior = opts.paper.prior_multiresolution;
        scalable = false;

    case 'scalable_landmark_bagging'
        anchors = max(baseAnchors,spectralRank);
        seeds = opts.paper.bagging_seeds(:)';
        orders = 1:viewCount;
        [components,componentNames,bankLandmarks] = ...
            build_paper_component_bank(X,anchors,seeds,orders,spectralRank);
        weights = ones(size(components,3),1)/size(components,3);
        [robustU,barycenterGap] = paper_subspace_barycenter( ...
            components,weights,spectralRank);
        recommendedPrior = opts.paper.prior_landmark_bagging;
        scalable = true;

    case 'scalable_order_multiscale'
        anchors = anchor_schedule(baseAnchors, ...
            opts.paper.scalable_anchor_ratios,n,spectralRank);
        seeds = baseSeed;
        orderLimit = min(opts.paper.max_orders, ...
            opts.paper.scalable_max_orders);
        orders = paper_view_orders(viewCount,orderLimit);
        [components,componentNames,bankLandmarks] = ...
            build_paper_component_bank(X,anchors,seeds,orders,spectralRank);
        weights = ones(size(components,3),1)/size(components,3);
        [robustU,barycenterGap] = paper_subspace_barycenter( ...
            components,weights,spectralRank);
        recommendedPrior = opts.paper.prior_order_symmetrization;
        scalable = true;

    case 'multiresolution'
        lowAnchors = min(n,max(spectralRank, ...
            round(baseAnchors*opts.paper.low_anchor_ratio)));
        highAnchors = min(n,max(spectralRank, ...
            round(baseAnchors*opts.paper.high_anchor_ratio)));
        anchors = [lowAnchors,highAnchors];
        seeds = baseSeed;
        orders = 1:viewCount;
        [components,componentNames,bankLandmarks] = ...
            build_paper_component_bank(X,anchors,seeds,orders,spectralRank);
        weights = [1-opts.paper.high_resolution_weight; ...
            opts.paper.high_resolution_weight];
        if size(components,3) ~= 2
            weights = ones(size(components,3),1)/size(components,3);
        end
        [robustU,barycenterGap] = paper_subspace_barycenter( ...
            components,weights,spectralRank);
        recommendedPrior = opts.paper.prior_multiresolution;
        scalable = false;

    case 'landmark_bagging'
        anchors = max(baseAnchors,spectralRank);
        seeds = opts.paper.bagging_seeds(:)';
        orders = 1:viewCount;
        [components,componentNames,bankLandmarks] = ...
            build_paper_component_bank(X,anchors,seeds,orders,spectralRank);
        weights = ones(size(components,3),1)/size(components,3);
        [robustU,barycenterGap] = paper_subspace_barycenter( ...
            components,weights,spectralRank);
        recommendedPrior = opts.paper.prior_landmark_bagging;
        scalable = true;

    case 'order_symmetrization'
        anchors = max(baseAnchors,spectralRank);
        seeds = baseSeed;
        orders = paper_view_orders(viewCount,opts.paper.max_orders);
        [components,componentNames,bankLandmarks] = ...
            build_paper_component_bank(X,anchors,seeds,orders,spectralRank);
        weights = ones(size(components,3),1)* ...
            (1-opts.paper.canonical_order_weight)/max(size(orders,1)-1,1);
        weights(1) = opts.paper.canonical_order_weight;
        if size(orders,1) == 1
            weights = 1;
        end
        [robustU,barycenterGap] = paper_subspace_barycenter( ...
            components,weights,spectralRank);
        recommendedPrior = opts.paper.prior_order_symmetrization;
        scalable = size(orders,1) <= opts.paper.max_orders;

    otherwise
        error('BCMKC:InvalidPaperStrategy', ...
            'Unknown paper.strategy: %s',strategy);
end

factor = robustU/sqrt(spectralRank);
factor = factor/max(norm(factor,'fro'),sqrt(eps));
info.strategy = strategy;
info.strategy_was_automatic = automatic;
info.robust_embedding = robustU;
info.components = components;
info.component_names = componentNames;
info.component_weights = weights(:)/sum(weights);
if isempty(baseLandmarks)
    info.landmarks = bankLandmarks(:);
else
    info.landmarks = [{baseLandmarks};bankLandmarks(:)];
end
info.barycenter_gap = barycenterGap;
info.recommended_prior = recommendedPrior;
info.base_landmarks = baseAnchors;
info.base_seed = baseSeed;
info.cluster_count = k;
info.spectral_rank = spectralRank;
info.factor_trace = sum(factor(:).^2);
info.uses_ground_truth = false;
info.orders = orders;
info.policy.anchor_counts = anchors(:)';
info.policy.seeds = seeds(:)';
info.policy.orders = orders;
info.policy.component_count = size(components,3);
info.policy.equal_component_weights = ...
    max(info.component_weights)-min(info.component_weights) < 10*eps;
info.policy.scalable = scalable;
info.policy.rank_multiplier = spectralRank/k;
info.policy.selection_signal = 'sample_count_and_view_count_only';
if exist('robustDetails','var')
    info.robust_details = robustDetails;
    info.policy.selection_signal = robustDetails.selection_signal;
end
if exist('hierarchical','var')
    info.hierarchical = rmfield(hierarchical, ...
        {'robust_embedding','components','landmarks','singular_values'});
    info.policy.selection_signal = ...
        'unlabeled subspace stability, cross-view agreement, and spectral separation';
end
end

function [agreement,centrality] = subspace_agreement(components,r)
viewCount = size(components,3);
agreement = eye(viewCount);
for a = 1:viewCount
    for b = a+1:viewCount
        value = norm(components(:,:,a)'*components(:,:,b),'fro')^2/r;
        agreement(a,b) = value;
        agreement(b,a) = value;
    end
end
centrality = max((sum(agreement,2)-1)/max(viewCount-1,1),eps);
end

function anchors = anchor_schedule(baseAnchors,ratios,n,spectralRank)
ratios = double(ratios(:)');
if isempty(ratios) || any(~isfinite(ratios)) || any(ratios <= 0)
    error('BCMKC:InvalidAnchorRatios', ...
        'Paper anchor ratios must be finite and positive.');
end
anchors = round(baseAnchors*ratios);
anchors = min(n,max(spectralRank,anchors));
anchors = unique(anchors,'stable');
end
