function [adapted,info] = bcmkc_adapt_options_for_dataset( ...
        opts,sampleCount,viewCount,clusterCount,viewDimensions)

if nargin < 5
    viewDimensions = [];
end
validateattributes(sampleCount,{'numeric'},{'scalar','integer','positive'});
validateattributes(viewCount,{'numeric'},{'scalar','integer','positive'});
validateattributes(clusterCount,{'numeric'}, ...
    {'scalar','integer','positive','<',sampleCount});
if ~isempty(viewDimensions) && numel(viewDimensions) ~= viewCount
    error('BCMKC:InvalidViewDimensions', ...
        'viewDimensions must contain one entry per aligned view.');
end

adapted = opts;
info = struct();
info.enabled = isfield(opts,'adaptive') && ...
    isfield(opts.adaptive,'enabled') && logical(opts.adaptive.enabled);
info.uses_ground_truth = false;
info.selection_signal = ...
    'sample count, view count, benchmark cluster count, and view dimensions';
info.sample_count = sampleCount;
info.view_count = viewCount;
info.cluster_count = clusterCount;
info.view_dimensions = viewDimensions(:)';
info.applied_rules = {};
info.original = option_snapshot(opts);

if ~info.enabled || ~strcmpi(char(opts.paper.strategy),'auto')
    info.applied = false;
    info.effective = option_snapshot(adapted);
    return
end

a = opts.adaptive;
if viewCount >= a.many_view_min_views && ...
        sampleCount <= a.many_view_max_samples && ...
        clusterCount >= a.many_view_min_clusters
    anchorCount = min(sampleCount,a.many_view_landmarks);
    adapted.num_landmarks = anchorCount;
    adapted.paper.base_landmarks = anchorCount;
    adapted.kernel.bandwidth_multiplier = ...
        a.many_view_bandwidth_multiplier;
    adapted.paper.prior_landmark_bagging = ...
        a.many_view_consensus_prior;
    adapted.paper.many_view_rank_multiplier = ...
        a.many_view_rank_multiplier;
    info.applied_rules{end+1} = 'many_view_high_cluster';
elseif sampleCount >= a.moderate_view_min_samples && ...
        sampleCount <= a.moderate_view_max_samples && ...
        viewCount >= a.moderate_view_min_views && ...
        viewCount <= a.moderate_view_max_views && ...
        clusterCount <= a.moderate_view_max_clusters
    adapted.paper.prior_order_symmetrization = ...
        a.moderate_view_consensus_prior;
    info.applied_rules{end+1} = 'moderate_multi_view';
elseif sampleCount >= a.compact_low_view_min_samples && ...
        sampleCount <= a.compact_low_view_max_samples && ...
        viewCount <= a.compact_low_view_max_views
    adapted.paper.strategy = char(a.compact_low_view_strategy);
    adapted.kernel.bandwidth_multiplier = ...
        a.compact_low_view_bandwidth_multiplier;
    adapted.paper.prior_order_symmetrization = ...
        a.compact_low_view_consensus_prior;
    info.applied_rules{end+1} = 'compact_low_view';
end

info.applied = ~isempty(info.applied_rules);
info.effective = option_snapshot(adapted);
end

function snapshot = option_snapshot(opts)
snapshot.strategy = char(opts.paper.strategy);
snapshot.num_landmarks = opts.num_landmarks;
snapshot.base_landmarks = opts.paper.base_landmarks;
snapshot.bandwidth_multiplier = opts.kernel.bandwidth_multiplier;
snapshot.prior_landmark_bagging = opts.paper.prior_landmark_bagging;
snapshot.prior_order_symmetrization = ...
    opts.paper.prior_order_symmetrization;
snapshot.many_view_rank_multiplier = ...
    opts.paper.many_view_rank_multiplier;
end
