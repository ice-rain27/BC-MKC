function [Sstar,objective] = paper_update_s_star(KH,k,order)

viewCount = size(KH,3);
if nargin < 3 || isempty(order)
    order = 1:viewCount;
end
if numel(order) ~= viewCount || ~isequal(sort(order),1:viewCount)
    error('BCMKC:InvalidViewOrder','order must be a permutation of all views.');
end
objective = 0;
for position = 1:viewCount
    view = order(position);
    [S,H] = paper_initialize(KH(:,:,view),k);
    if position == 1
        Sstar = S;
    else
        [Sstar,objective] = each_anchormatrix( ...
            KH(:,:,view),S,H,eye(k),Sstar);
    end
end
end
