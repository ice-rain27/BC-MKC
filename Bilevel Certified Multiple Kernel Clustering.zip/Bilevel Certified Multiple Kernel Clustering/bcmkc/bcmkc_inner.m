function [model,history] = bcmkc_inner(factors,k,beta0,opts)

m = numel(factors);
if numel(beta0) ~= m
    error('BCMKC:WeightDimension','beta0 must have one element per view.');
end
if ~(isscalar(opts.inner.mu) && isfinite(opts.inner.mu) && opts.inner.mu > 0)
    error('BCMKC:InvalidMu','The strong-convexity parameter mu must be positive.');
end

beta0 = project_simplex(beta0);
beta = beta0;
previousU = [];
history.beta_delta = nan(opts.inner.max_iter,1);
history.projector_delta = nan(opts.inner.max_iter,1);
history.objective = nan(opts.inner.max_iter,1);
history.eigengap = nan(opts.inner.max_iter,1);
converged = false;

for iter = 1:opts.inner.max_iter
    [target,spectral,scores] = bcmkc_fixed_response( ...
        factors,beta,beta0,k,opts);
    nextBeta = (1-opts.inner.damping)*beta + opts.inner.damping*target;
    nextBeta = project_simplex(nextBeta);

    history.beta_delta(iter) = norm(nextBeta-beta);
    if isempty(previousU)
        history.projector_delta(iter) = inf;
    else
        history.projector_delta(iter) = projector_distance(previousU,spectral.U);
    end
    history.objective(iter) = -beta'*scores + ...
        0.5*opts.inner.mu*norm(beta-beta0)^2;
    history.eigengap(iter) = spectral.eigengap;

    previousU = spectral.U;
    beta = nextBeta;
    if history.beta_delta(iter) <= opts.inner.tol_beta && ...
            history.projector_delta(iter) <= opts.inner.tol_projector
        converged = true;
        break;
    end
end

history.beta_delta = history.beta_delta(1:iter);
history.projector_delta = history.projector_delta(1:iter);
history.objective = history.objective(1:iter);
history.eigengap = history.eigengap(1:iter);

[betaResponse,spectral,scores] = bcmkc_fixed_response( ...
    factors,beta,beta0,k,opts);
model.beta = beta;
model.beta0 = beta0;
model.U = spectral.U;
model.lambda = spectral.lambda;
model.eigengap = spectral.eigengap;
model.eig_residual = spectral.eig_residual;
model.eigs_flag = spectral.eigs_flag;
model.alignment = scores;
model.fixed_point_residual = norm(beta-betaResponse);
model.objective = -beta'*scores + 0.5*opts.inner.mu*norm(beta-beta0)^2;
model.converged = converged || model.fixed_point_residual <= 5*opts.inner.tol_beta;
model.iterations = iter;
model.k = k;
model.mu = opts.inner.mu;
end

