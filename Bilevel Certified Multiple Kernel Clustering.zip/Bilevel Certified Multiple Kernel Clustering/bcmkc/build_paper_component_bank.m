function [components,names,landmarks] = build_paper_component_bank( ...
    X,anchors,seeds,orders,spectralRank)

anchors = unique(round(double(anchors(:)')),'stable');
seeds = double(seeds(:)');
if isempty(anchors) || isempty(seeds) || isempty(orders)
    error('BCMKC:EmptyPaperBank', ...
        'The anchor, seed, and order schedules must all be nonempty.');
end
n = size(X{1},1);
viewCount = numel(X);
if size(orders,2) ~= viewCount
    error('BCMKC:InvalidViewOrderBank', ...
        'Every order must contain one position per view.');
end
if any(anchors < spectralRank) || any(anchors > n)
    error('BCMKC:InvalidPaperAnchors', ...
        'Every anchor count must lie in [spectralRank,n].');
end

componentCount = numel(anchors)*numel(seeds)*size(orders,1);
components = zeros(n,spectralRank,componentCount);
names = cell(componentCount,1);
landmarks = cell(numel(anchors),numel(seeds));
component = 0;
for a = 1:numel(anchors)
    for s = 1:numel(seeds)
        [KH,landmarks{a,s}] = paper_build_cross_kernels( ...
            X,anchors(a),seeds(s));
        for o = 1:size(orders,1)
            component = component+1;
            components(:,:,component) = paper_update_s_star( ...
                KH,spectralRank,orders(o,:));
            names{component} = sprintf('anchors_%d_seed_%d_order_%d', ...
                anchors(a),seeds(s),o);
        end
    end
end
end
