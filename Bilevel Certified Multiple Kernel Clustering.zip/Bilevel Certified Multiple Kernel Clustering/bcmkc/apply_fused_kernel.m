function Y = apply_fused_kernel(factors,beta,X)

m = numel(factors);
Y = zeros(size(X));
for v = 1:m
    if beta(v) > 0
        Y = Y + beta(v)*(factors{v}*(factors{v}'*X));
    end
end
end

