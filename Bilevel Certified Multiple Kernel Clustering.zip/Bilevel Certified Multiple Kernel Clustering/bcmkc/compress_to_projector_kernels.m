function [compressed,info] = compress_to_projector_kernels( ...
    factors,spectralRank,opts)

m = numel(factors);
compressed = cell(m,1);
info = repmat(struct(),m,1);
for v = 1:m
    Phi = factors{v};
    rankRequested = min([spectralRank,size(Phi,1)-1,size(Phi,2)]);
    if rankRequested < spectralRank
        error('BCMKC:InsufficientViewRank', ...
            'View %d has dimension %d but spectral rank r=%d.', ...
            v,rankRequested,spectralRank);
    end
    svdOpts.tol = opts.inner.eigs_tol;
    svdOpts.maxit = opts.inner.eigs_maxit;
    [U,S,~,flag] = svds(Phi,spectralRank,'largest',svdOpts);
    [values,order] = sort(diag(S),'descend');
    U = real(U(:,order));
    [U,~] = qr(U,0);
    compressed{v} = U/sqrt(spectralRank);
    info(v).singular_values = values;
    info(v).svds_flag = flag;
    info(v).rank = spectralRank;
end
end
