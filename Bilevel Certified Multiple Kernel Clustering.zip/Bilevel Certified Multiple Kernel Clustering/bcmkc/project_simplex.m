function x = project_simplex(y)

y = double(y(:));
if isempty(y) || any(~isfinite(y))
    error('BCMKC:InvalidSimplexInput','Simplex input must be finite and nonempty.');
end
u = sort(y,'descend');
cssv = cumsum(u) - 1;
rho = find(u - cssv./(1:numel(u))' > 0,1,'last');
if isempty(rho)
    x = ones(size(y))/numel(y);
    return;
end
theta = cssv(rho)/rho;
x = max(y-theta,0);
x = x/max(sum(x),eps);
end

