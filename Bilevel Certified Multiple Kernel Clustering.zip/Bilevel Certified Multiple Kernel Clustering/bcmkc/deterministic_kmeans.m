function [labels,centers,objective] = deterministic_kmeans(X,k,options)

if nargin < 3 || isempty(options)
    options.max_iter = 100;
end
if ~isfield(options,'max_iter')
    options.max_iter = 100;
end
if ~isfield(options,'multistart_threshold')
    options.multistart_threshold = inf;
end
if ~isfield(options,'replicates')
    options.replicates = 1;
end
if ~isfield(options,'seed')
    options.seed = 5489;
end
if ~isfield(options,'selection')
    options.selection = 'sse';
end
X = double(X);
n = size(X,1);
if k < 1 || k > n
    error('BCMKC:InvalidClusterCount','Invalid number of clusters.');
end

replicates = 1;
if n >= options.multistart_threshold
    replicates = max(1,round(options.replicates));
end
stream = RandStream('mt19937ar','Seed',options.seed);
bestScore = inf;
bestSSE = inf;
labels = [];
centers = [];

for replicate = 1:replicates
    if replicate == 1
        initialCenters = farthest_first_centers(X,k);
    else
        initialCenters = X(randperm(stream,n,k),:);
    end
    [candidateLabels,candidateCenters,minDistance] = lloyd_run( ...
        X,initialCenters,options.max_iter);
    candidateSSE = sum(minDistance);
    switch lower(options.selection)
        case 'sum_distance'
            candidateScore = sum(sqrt(max(minDistance,0)));
        case 'sse'
            candidateScore = candidateSSE;
        otherwise
            error('BCMKC:InvalidDiscretizerSelection', ...
                'discretizer.selection must be ''sum_distance'' or ''sse''.')
    end
    if candidateScore < bestScore-1e-12 || ...
            (abs(candidateScore-bestScore) <= 1e-12 && candidateSSE < bestSSE)
        bestScore = candidateScore;
        bestSSE = candidateSSE;
        labels = candidateLabels;
        centers = candidateCenters;
    end
end
objective = bestSSE;
end

function D = squared_distances(A,B)
aa = sum(A.^2,2);
bb = sum(B.^2,2)';
D = max(0,bsxfun(@plus,aa,bb)-2*(A*B'));
end

function centers = farthest_first_centers(X,k)
globalCenter = mean(X,1);
dGlobal = sum(bsxfun(@minus,X,globalCenter).^2,2);
[~,first] = max(dGlobal);
centerIndex = zeros(k,1);
centerIndex(1) = first;
nearest = sum(bsxfun(@minus,X,X(first,:)).^2,2);
for c = 2:k
    nearest(centerIndex(1:c-1)) = -inf;
    [~,centerIndex(c)] = max(nearest);
    candidate = sum(bsxfun(@minus,X,X(centerIndex(c),:)).^2,2);
    nearest = min(nearest,candidate);
end
centers = X(centerIndex,:);
end

function [labels,centers,minDistance] = lloyd_run(X,centers,maxIter)
n = size(X,1);
k = size(centers,1);
labels = zeros(n,1);
for iter = 1:maxIter
    oldLabels = labels;
    distances = squared_distances(X,centers);
    [minDistance,labels] = min(distances,[],2);

    missing = setdiff((1:k)',unique(labels));
    for j = 1:numel(missing)
        [~,idx] = max(minDistance);
        labels(idx) = missing(j);
        minDistance(idx) = -inf;
    end
    for c = 1:k
        centers(c,:) = mean(X(labels==c,:),1);
    end
    if isequal(labels,oldLabels)
        break;
    end
end
distances = squared_distances(X,centers);
minDistance = distances(sub2ind(size(distances),(1:n)',labels));
end
