function [transformed,info] = robust_asinh_views(X)

if ~iscell(X) || isempty(X)
    error('BCMKC:InvalidViews','X must be a nonempty cell array.');
end
transformed = cell(size(X));
info = repmat(struct('center',[],'scale',[], ...
    'rms_fallback_count',0,'unit_fallback_count',0),numel(X),1);
for v = 1:numel(X)
    Z = double(X{v});
    center = median(Z,1);
    Z = bsxfun(@minus,Z,center);
    scale = 1.4826*median(abs(Z),1);
    fallback = sqrt(mean(Z.^2,1));
    bad = ~isfinite(scale) | scale < 1e-12;
    scale(bad) = fallback(bad);
    unitFallback = ~isfinite(scale) | scale < 1e-12;
    scale(unitFallback) = 1;
    Z = asinh(bsxfun(@rdivide,Z,scale));
    Z(~isfinite(Z)) = 0;
    transformed{v} = Z;
    info(v).center = center;
    info(v).scale = scale;
    info(v).rms_fallback_count = nnz(bad);
    info(v).unit_fallback_count = nnz(unitFallback);
end
end
