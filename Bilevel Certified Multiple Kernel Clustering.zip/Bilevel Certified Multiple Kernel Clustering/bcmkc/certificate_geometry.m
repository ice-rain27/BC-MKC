function geometry = certificate_geometry(factors,k,mu,gamma)

[opNorms,froNorms] = kernel_operator_norms(factors);
geometry.operator_norms = opNorms;
geometry.frobenius_norms = froNorms;
geometry.kappa = norm(opNorms,2);
geometry.b = norm(froNorms,2)/mu;
if gamma > 0
    geometry.L = 2*sqrt(2*k)/gamma;
    geometry.q = geometry.L*geometry.kappa*geometry.b;
else
    geometry.L = inf;
    geometry.q = inf;
end
end

