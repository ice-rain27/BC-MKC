function [factors,info,processedViews] = build_nystrom_factors( ...
        X,opts,retainProcessedViews)

if nargin < 3 || isempty(retainProcessedViews)
    retainProcessedViews = true;
end

if ~iscell(X) || isempty(X)
    error('BCMKC:InvalidViews','X must be a nonempty cell array of views.');
end
X = X(:);
m = numel(X);
n = size(X{1},1);
if any(cellfun(@(z) size(z,1) ~= n,X))
    error('BCMKC:SampleMismatch','All views must contain the same samples.');
end

s = min(opts.num_landmarks,n);
factors = cell(m,1);
if retainProcessedViews
    processedViews = cell(m,1);
else
    processedViews = cell(0,1);
end
info = repmat(struct(),m,1);

for v = 1:m
    [Xv,preprocessStats] = preprocess_view(X{v},opts);
    scale = estimate_rbf_scale(Xv,opts);
    [landmarks,samplingInfo] = recursive_rls_landmarks_fixed( ...
        Xv,s,scale,opts);
    C = rbf_kernel_fixed(Xv,Xv(landmarks,:),scale);
    W = rbf_kernel_fixed(Xv(landmarks,:),Xv(landmarks,:),scale);
    W = (W+W')/2;

    relativeReg = opts.nystrom.regularization*max(trace(W)/size(W,1),1);
    [Q,D] = eig(W+relativeReg*eye(size(W)),'vector');
    D = real(D);
    cutoff = opts.nystrom.rank_tolerance*max(max(D),1);
    keep = D > cutoff;
    if ~any(keep)
        error('BCMKC:DegenerateNystrom','Nyström landmark kernel has zero numerical rank.');
    end
    Phi = real(C*Q(:,keep)*diag(1./sqrt(D(keep))));
    rawTrace = sum(Phi(:).^2);
    if opts.kernel.degree_normalize
        degree = Phi*(Phi'*ones(n,1));
        positiveDegree = degree(degree > 0 & isfinite(degree));
        if isempty(positiveDegree)
            degreeFloor = 1;
        else
            degreeFloor = max(1e-12,1e-10*median(positiveDegree));
        end
        degree(~isfinite(degree) | degree < degreeFloor) = degreeFloor;
        Phi = bsxfun(@rdivide,Phi,sqrt(degree));
    end
    Phi = Phi/max(norm(Phi,'fro'),sqrt(eps));
    factors{v} = Phi;
    if retainProcessedViews
        processedViews{v} = Xv;
    end

    gramSmall = Phi'*Phi;
    opNorm = max(real(eig((gramSmall+gramSmall')/2)));
    traceApprox = sum(Phi(:).^2);
    info(v).landmarks = landmarks;
    info(v).scale = scale;
    info(v).preprocess = preprocessStats;
    info(v).rank = size(Phi,2);
    info(v).operator_norm = max(opNorm,0);
    info(v).frobenius_norm = norm(gramSmall,'fro');
    info(v).trace_approx = traceApprox;
    info(v).nominal_trace_residual = max(0,1-rawTrace/n);
    info(v).degree_normalized = opts.kernel.degree_normalize;
    info(v).regularization = relativeReg;
    info(v).sampling = samplingInfo;
end
end
