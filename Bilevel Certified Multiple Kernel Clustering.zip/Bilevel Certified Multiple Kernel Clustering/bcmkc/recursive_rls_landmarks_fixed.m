function [landmarks,info] = recursive_rls_landmarks_fixed(X,s,scale,opts)

n = size(X,1);
s = min(max(round(s),1),n);
if s == n
    landmarks = (1:n)';
    info.levels = 0;
    info.final_probabilities = ones(n,1)/n;
    return;
end

if opts.nystrom.accelerated
    sLevel = ceil(sqrt((n*s+s^3)/(4*n)));
    sLevel = min(max(sLevel,1),s);
else
    sLevel = s;
end
oversamp = max(log(max(sLevel,2)),1);
targetRank = max(1,ceil(sLevel/(4*oversamp)));
nLevels = max(1,ceil(log(n/sLevel)/log(2)));
perm = randperm(n);

levelSize = zeros(1,nLevels+1);
levelSize(1) = n;
for i = 2:nLevels+1
    levelSize(i) = ceil(levelSize(i-1)/2);
end

samp = (1:levelSize(end))';
rInd = perm(samp)';
weights = ones(numel(rInd),1);
finalLevs = ones(n,1)/n;

for level = nLevels:-1:1
    currentSize = levelSize(level);
    rIndCurrent = perm(1:currentSize)';
    KS = rbf_kernel_fixed(X(rIndCurrent,:),X(rInd,:),scale);
    SKS = KS(samp,:);
    SKS = (SKS+SKS')/2;

    weighted = bsxfun(@times,bsxfun(@times,SKS,weights),weights');
    eigvals = sort(real(eig((weighted+weighted')/2)),'descend');
    keep = min(targetRank,numel(eigvals));
    lambda = (trace(weighted)-sum(max(eigvals(1:keep),0)))/targetRank;
    lambda = max(real(lambda),1e-7);

    diagonalReg = lambda./max(weights.^2,realmin);
    system = SKS + diag(diagonalReg);
    system = (system+system')/2;
    R = system\eye(size(system));
    leverageBase = max(0,1-sum((KS*R).*KS,2));

    if level ~= 1
        levs = min(1,(oversamp/lambda)*leverageBase);
        samp = find(rand(currentSize,1) < levs);
        if isempty(samp)
            take = min(sLevel,currentSize);
            samp = randperm(currentSize,take)';
            levs = ones(currentSize,1)*(take/currentSize);
        end
        weights = sqrt(1./max(levs(samp),realmin));
    else
        levs = leverageBase/lambda;
        samp = weighted_sample_without_replacement(levs,s);
        finalLevs = levs/max(sum(levs),eps);
    end
    rInd = perm(samp)';
end

landmarks = rInd(:);
if numel(unique(landmarks)) ~= s
    error('BCMKC:LandmarkSamplingFailure', ...
        'Recursive sampler did not return the requested unique landmarks.');
end
info.levels = nLevels;
info.final_probabilities = finalLevs;
end
