function cert = bcmkc_certify(model,factors,core,epsilon,opts)

m = numel(factors);
if isscalar(epsilon)
    epsilon = repmat(double(epsilon),m,1);
else
    epsilon = double(epsilon(:));
end
if numel(epsilon) ~= m || any(~isfinite(epsilon)) || any(epsilon < 0)
    error('BCMKC:InvalidThreatBudget', ...
        'epsilon must be a nonnegative scalar or one value per view.');
end

cert = empty_certificate(size(model.U,1));
cert.requested_epsilon = epsilon;
cert.assumptions.fixed_landmarks = true;
cert.assumptions.fixed_bandwidths = true;
cert.assumptions.fixed_cluster_count = true;
cert.assumptions.fixed_cores = true;
cert.assumptions.row_normalized_decoder = true;
cert.assumptions.ordinary_double_precision = true;
cert.assumptions.semantic_correctness = false;

approx = opts.certificate.full_kernel_approx_bound;
if isempty(approx)
    effectiveEpsilon = epsilon;
    cert.scope = 'fixed-landmark Nystrom approximate kernels';
    cert.assumptions.full_kernel_covered = false;
else
    if isscalar(approx)
        approx = repmat(double(approx),m,1);
    else
        approx = double(approx(:));
    end
    if numel(approx) ~= m || any(~isfinite(approx)) || any(approx < 0)
        error('BCMKC:InvalidApproximationBound', ...
            'full_kernel_approx_bound must be nonnegative per view.');
    end
    effectiveEpsilon = epsilon + 2*approx;
    cert.scope = 'full kernels with user-supplied uniform approximation bounds';
    cert.assumptions.full_kernel_covered = true;
end
cert.effective_epsilon = effectiveEpsilon;

gamma = model.eigengap;
cert.eigengap = gamma;
if ~(isfinite(gamma) && gamma > 0)
    cert.status = 'ABSTAIN_GAP';
    cert.reason = 'The nominal top-r eigengap is not positive.';
    return;
end

if isfield(model,'kernel_operator_norms') && ...
        isfield(model,'kernel_frobenius_norms')
    opNorms = model.kernel_operator_norms;
    froNorms = model.kernel_frobenius_norms;
else
    [opNorms,froNorms] = kernel_operator_norms(factors);
end
if isfield(model,'spectral_rank')
    spectralRank = model.spectral_rank;
else
    spectralRank = model.k;
end
cert.spectral_rank = spectralRank;
mu = model.mu;
L = 2*sqrt(2*spectralRank)/gamma;
a = spectralRank*norm(effectiveEpsilon,2)/mu;
b = norm(froNorms,2)/mu;
kappa = norm(opNorms,2);
q = L*kappa*b;
d = max(effectiveEpsilon);

cert.constants.L = L;
cert.constants.a = a;
cert.constants.b = b;
cert.constants.kappa = kappa;
cert.constants.q = q;
cert.kernel_operator_norms = opNorms;
cert.kernel_frobenius_norms = froNorms;

if ~(isfinite(q) && q < 1)
    cert.status = 'ABSTAIN_CONTRACTION';
    cert.reason = 'The closed-loop response bound is not contractive (q >= 1).';
    return;
end

attackRK = (d+kappa*a)/(1-q);
attackRP = L*attackRK;
cert.attack_kernel_bound = attackRK;
cert.attack_projector_bound = attackRP;

if ~(isfinite(attackRK) && attackRK < gamma/2)
    cert.status = 'ABSTAIN_PERTURBATION';
    cert.reason = 'The perturbation bound can cross the certified eigengap.';
    return;
end

safety = opts.certificate.residual_safety_factor;
eigPosterior = safety*2*sqrt(2)*model.eig_residual/gamma;
weightPosterior = safety*L*kappa*model.fixed_point_residual;
solverRP = (eigPosterior+weightPosterior)/(1-q);
cert.eig_solver_projector_bound = eigPosterior;
cert.weight_solver_projector_bound = weightPosterior;
cert.solver_projector_bound = solverRP;
cert.total_projector_bound = attackRP+solverRP;

if ~isfinite(cert.total_projector_bound)
    cert.status = 'ABSTAIN_RESIDUAL';
    cert.reason = 'The inexact-solver correction is not finite.';
    return;
end

[labels,scores,margins] = partition_fixed_cores(model.U,core);
n = numel(labels);
sampleMask = true(n,1);
threshold = zeros(n,1);
rowSquaredNorm = sum(model.U.^2,2);
rowNorm = sqrt(rowSquaredNorm);
cert.min_row_norm = min(rowNorm);
if any(~isfinite(rowNorm)) || cert.total_projector_bound >= cert.min_row_norm
    cert.status = 'ABSTAIN_NORMALIZATION';
    cert.reason = ['The projector perturbation bound can collapse a row ', ...
        'before spectral row normalization.'];
    return;
end

inverseRowSquaredNorm = 1./rowSquaredNorm;
weightedMembership = spdiags(inverseRowSquaredNorm,0,n,n)*core.A;
weightedSquaredMembership = spdiags(inverseRowSquaredNorm,0,n,n)*(core.A.^2);
coreTerm = full(sum(weightedSquaredMembership,1));
h = bsxfun(@plus,inverseRowSquaredNorm,coreTerm)-2*full(weightedMembership);
normalizedEmbeddingBound = 2*cert.total_projector_bound*sqrt(max(h,0));
distances = max(-scores,0);
distanceError = 2*sqrt(distances).*normalizedEmbeddingBound + ...
    normalizedEmbeddingBound.^2;
for i = 1:n
    c = labels(i);
    worstThreshold = 0;
    for dCluster = 1:numel(core.sizes)
        if dCluster == c
            continue;
        end
        rhs = distanceError(i,c)+distanceError(i,dCluster);
        lhs = scores(i,c)-scores(i,dCluster);
        worstThreshold = max(worstThreshold,rhs);
        if lhs <= rhs + opts.certificate.margin_tolerance
            sampleMask(i) = false;
        end
    end
    threshold(i) = worstThreshold;
end

cert.labels = labels;
cert.sample_mask = sampleMask;
cert.coverage = mean(sampleMask);
cert.global = all(sampleMask);
cert.margins = margins;
cert.margin_thresholds = threshold;
cert.row_norms = rowNorm;
cert.normalized_embedding_bounds = normalizedEmbeddingBound;
cert.distance_error_bounds = distanceError;
cert.certified_indices = find(sampleMask);
cert.abstained_indices = find(~sampleMask);
cert.coassignment_invariant = cert.global;
if cert.global
    cert.status = 'CERTIFIED_GLOBAL';
    cert.reason = 'Every sample passes the fixed-core assignment margin.';
elseif any(sampleMask)
    cert.status = 'CERTIFIED_PARTIAL';
    cert.reason = 'Only relations involving certified samples are reportable.';
else
    cert.status = 'ABSTAIN_MARGIN';
    cert.reason = 'No sample passes the residual-corrected assignment margin.';
end
end

function cert = empty_certificate(n)
cert.status = 'ABSTAIN_UNCHECKED';
cert.reason = 'Certificate was not evaluated.';
cert.scope = '';
cert.coverage = 0;
cert.global = false;
cert.coassignment_invariant = false;
cert.sample_mask = false(n,1);
cert.certified_indices = zeros(0,1);
cert.abstained_indices = (1:n)';
cert.assumptions = struct();
cert.constants = struct();
end
