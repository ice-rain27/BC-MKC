function spectral = fused_topk(factors,beta,k,opts)

beta = project_simplex(beta);
n = size(factors{1},1);
if k < 1 || k+1 > n
    error('BCMKC:InvalidClusterCount','Need 1 <= k < number of samples.');
end

eigsOpts.tol = opts.inner.eigs_tol;
eigsOpts.maxit = opts.inner.eigs_maxit;
v0 = sin((1:n)'*sqrt(2));
eigsOpts.v0 = v0/norm(v0);

if n <= opts.inner.dense_threshold
    K = zeros(n,n);
    for v = 1:numel(factors)
        if beta(v) > 0
            K = K + beta(v)*(factors{v}*factors{v}');
        end
    end
    K = (K+K')/2;
    [U,D,flag] = eigs(K,k+1,'largestreal',eigsOpts);
else
    Afun = @(z) apply_fused_kernel(factors,beta,z);
    functionOpts = eigsOpts;
    functionOpts.issym = true;
    functionOpts.isreal = true;
    [U,D,flag] = eigs(Afun,n,k+1,'largestreal',functionOpts);
end

lambda = real(diag(D));
[lambda,order] = sort(lambda,'descend');
U = real(U(:,order));
U = U(:,1:k);
[U,~] = qr(U,0);

KU = apply_fused_kernel(factors,beta,U);
rayleigh = U'*KU;
residual = norm(KU-U*rayleigh,'fro');

spectral.U = U;
spectral.lambda = lambda;
spectral.eigengap = max(lambda(k)-lambda(k+1),0);
spectral.eig_residual = residual;
spectral.eigs_flag = flag;
end
