function out = merge_options(defaults, overrides)

out = defaults;
if nargin < 2 || isempty(overrides)
    return;
end
if ~isstruct(overrides) || ~isscalar(overrides)
    error('BCMKC:InvalidOptions','Options override must be a scalar struct.');
end

names = fieldnames(overrides);
for i = 1:numel(names)
    name = names{i};
    value = overrides.(name);
    if isfield(out,name) && isstruct(out.(name)) && isstruct(value)
        out.(name) = merge_options(out.(name),value);
    else
        out.(name) = value;
    end
end
end

