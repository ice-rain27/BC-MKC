function [scores,distances] = fixed_core_scores(U,core)

embedding = row_normalize(U);
projectedCore = embedding'*core.A;
crossTerm = embedding*projectedCore;
sampleNorm = sum(embedding.^2,2);
coreNorm = sum(projectedCore.^2,1);
distances = max(0,bsxfun(@plus,sampleNorm,coreNorm)-2*crossTerm);
scores = -distances;
end
