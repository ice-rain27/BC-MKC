function C = coassignment_matrix(labels)

labels = labels(:);
C = labels == labels';
end
