function [factors,info] = normalize_kernel_factors(factors)

if ~iscell(factors) || isempty(factors)
    error('BCMKC:InvalidFactors','factors must be a nonempty cell array.');
end
info = repmat(struct('trace_before',0,'trace_after',0,'scale',0), ...
    numel(factors),1);
for q = 1:numel(factors)
    factor = double(factors{q});
    traceBefore = sum(factor(:).^2);
    if ~(isfinite(traceBefore) && traceBefore > eps)
        error('BCMKC:DegenerateFactor', ...
            'Kernel factor %d has a nonpositive or nonfinite trace.',q);
    end
    scale = sqrt(traceBefore);
    factor = factor/scale;
    factors{q} = factor;
    info(q).trace_before = traceBefore;
    info(q).trace_after = sum(factor(:).^2);
    info(q).scale = scale;
end
end
