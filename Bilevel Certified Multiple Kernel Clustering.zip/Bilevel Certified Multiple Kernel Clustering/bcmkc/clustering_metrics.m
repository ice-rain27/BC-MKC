function metrics = clustering_metrics(truth,prediction)

truth = relabel_consecutive(truth);
prediction = relabel_consecutive(prediction);
if numel(truth) ~= numel(prediction)
    error('BCMKC:MetricSizeMismatch','Truth and prediction sizes differ.');
end
n = numel(truth);
kt = max(truth);
kp = max(prediction);
contingency = accumarray([truth,prediction],1,[kt,kp]);

mapped = bestMap(truth,prediction);
metrics.ACC = mean(mapped==truth);

pij = contingency/n;
pi = sum(pij,2);
pj = sum(pij,1);
expected = pi*pj;
mask = pij > 0 & expected > 0;
mutual = sum(pij(mask).*log(pij(mask)./expected(mask)));
Ht = -sum(pi(pi>0).*log(pi(pi>0)));
Hp = -sum(pj(pj>0).*log(pj(pj>0)));
metrics.NMI = mutual/max(sqrt(Ht*Hp),eps);
metrics.Purity = sum(max(contingency,[],1))/n;

choose2 = @(z) z.*(z-1)/2;
sumComb = sum(choose2(contingency(:)));
rowComb = sum(choose2(sum(contingency,2)));
colComb = sum(choose2(sum(contingency,1)));
totalComb = choose2(n);
expectedIndex = rowComb*colComb/max(totalComb,eps);
maxIndex = 0.5*(rowComb+colComb);
metrics.ARI = (sumComb-expectedIndex)/max(maxIndex-expectedIndex,eps);
end
