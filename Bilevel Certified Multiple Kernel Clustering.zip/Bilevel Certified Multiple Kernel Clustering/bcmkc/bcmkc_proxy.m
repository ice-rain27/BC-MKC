function [value,components] = bcmkc_proxy(model,factors,core,beta0,opts,baseGeometry)

[scores,~] = fixed_core_scores(model.U,core);
reference = core.reference_labels;
n = size(scores,1);
k = size(scores,2);
temp = max(opts.outer.margin_temperature,eps);

if k == 1
    smoothMargin = inf;
    balancePenalty = 0;
else
    perSample = zeros(n,1);
    for i = 1:n
        target = scores(i,reference(i));
        other = scores(i,:);
        other(reference(i)) = [];
        z = other/temp;
        zmax = max(z);
        lse = temp*(zmax+log(sum(exp(z-zmax))));
        perSample(i) = target-lse;
    end
    z = -perSample/temp;
    zmax = max(z);
    smoothMargin = -temp*(zmax+log(mean(exp(z-zmax))));

    assignTemp = max(opts.outer.assignment_temperature,eps);
    logits = scores/assignTemp;
    logits = bsxfun(@minus,logits,max(logits,[],2));
    probability = exp(logits);
    probability = bsxfun(@rdivide,probability,sum(probability,2));
    balancePenalty = sum((mean(probability,1)-1/k).^2);
end

alignment = model.beta'*model.alignment;
if nargin < 6 || isempty(baseGeometry)
    geometry = certificate_geometry(factors,model.k,model.mu,model.eigengap);
else
    geometry = baseGeometry;
    if model.eigengap > 0
        geometry.L = 2*sqrt(2*model.k)/model.eigengap;
        geometry.q = geometry.L*geometry.kappa*geometry.b;
    else
        geometry.L = inf;
        geometry.q = inf;
    end
end
qPenalty = max(0,geometry.q-opts.outer.q_target)^2;
beta0 = project_simplex(beta0);
entropy = -sum(beta0.*log(max(beta0,realmin)));

value = opts.outer.quality_weight*alignment + ...
    opts.outer.margin_weight*smoothMargin + ...
    opts.outer.gap_weight*model.eigengap - ...
    opts.outer.contraction_weight*qPenalty - ...
    opts.outer.balance_weight*balancePenalty + ...
    opts.outer.entropy_weight*entropy;

components.alignment = alignment;
components.smooth_margin = smoothMargin;
components.eigengap = model.eigengap;
components.q = geometry.q;
components.balance_penalty = balancePenalty;
components.prior_entropy = entropy;
end
