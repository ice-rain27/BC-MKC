function beta = softmax_simplex(logits)

logits = double(logits(:));
logits = logits - max(logits);
beta = exp(logits);
beta = beta/sum(beta);
end

