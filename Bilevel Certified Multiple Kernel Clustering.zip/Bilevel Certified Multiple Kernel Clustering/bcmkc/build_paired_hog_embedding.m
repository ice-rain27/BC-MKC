function [scores,info] = build_paired_hog_embedding(X,rankRequested,opts)

X = X(:);
if numel(X) ~= 2 || size(X{1},1) ~= size(X{2},1) || ...
        size(X{1},2) ~= size(X{2},2)
    error('BCMKC:PairedImageShape', ...
        'paired_image_hog requires two aligned equal-width views.');
end
n = size(X{1},1);
dimension = size(X{1},2);
side = round(sqrt(double(dimension)));
if side^2 ~= dimension
    error('BCMKC:PairedImageShape', ...
        'The paired views must contain flattened square images.');
end
cellSize = double(opts.paper.paired_hog_cell_size(:)');
if numel(cellSize) ~= 2 || any(cellSize < 1) || ...
        any(cellSize ~= round(cellSize)) || ...
        mod(side,cellSize(1)) ~= 0 || mod(side,cellSize(2)) ~= 0
    error('BCMKC:InvalidHOGCellSize', ...
        'paired_hog_cell_size must divide the image side exactly.');
end
rankRequested = min([rankRequested,n-1]);
precomputed = opts.paper.paired_hog_precomputed;
if ~isempty(precomputed)
    valid = isstruct(precomputed) && isscalar(precomputed) && ...
        isfield(precomputed,'scores') && isfield(precomputed,'info') && ...
        isfield(precomputed,'sample_count') && ...
        isfield(precomputed,'feature_dimension') && ...
        isfield(precomputed,'rank') && ...
        precomputed.sample_count == n && ...
        precomputed.feature_dimension == dimension && ...
        precomputed.rank == rankRequested && ...
        isequal(size(precomputed.scores),[n,rankRequested]);
    if ~valid
        error('BCMKC:InvalidPrecomputedHOG', ...
            'The paired HOG cache does not match this dataset or rank.');
    end
    scores = precomputed.scores;
    info = precomputed.info;
    info.cache_hit = true;
    return
end
images = 0.5*single(X{1})+0.5*single(X{2});
hasHOG = exist('extractHOGFeatures','file') == 2;

if hasHOG
    prototype = extractHOGFeatures(reshape(images(1,:),side,side), ...
        'CellSize',cellSize);
    features = zeros(n,numel(prototype),'single');
    useParallel = license('test','Distrib_Computing_Toolbox');
    if useParallel
        parfor i = 1:n
            features(i,:) = single(extractHOGFeatures( ...
                reshape(images(i,:),side,side),'CellSize',cellSize));
        end
    else
        for i = 1:n
            features(i,:) = single(extractHOGFeatures( ...
                reshape(images(i,:),side,side),'CellSize',cellSize));
        end
    end
else
    features = fixed_sobel_histograms(images,side,cellSize,9);
    useParallel = false;
end
clear images
if rankRequested > size(features,2)
    error('BCMKC:InsufficientHOGRank', ...
        ['Requested HOG-PCA rank %d exceeds the descriptor ', ...
        'dimension %d.'],rankRequested,size(features,2));
end

featureMean = mean(features,1);
featureScale = std(features,0,1);
featureScale(featureScale < sqrt(eps('single')) | ...
    ~isfinite(featureScale)) = 1;
features = bsxfun(@rdivide, ...
    bsxfun(@minus,features,featureMean),featureScale);
[scores,singularValues] = fixed_randomized_pca( ...
    features,rankRequested,opts.paper.paired_hog_pca_seed);
scores = double(scores);
if numel(singularValues) > rankRequested
    normalizedGap = (singularValues(rankRequested)- ...
        singularValues(rankRequested+1))/max(singularValues(1),eps);
else
    normalizedGap = singularValues(rankRequested)/ ...
        max(singularValues(1),eps);
end

info.image_side = side;
info.cell_size = cellSize;
info.descriptor_dimension = size(features,2);
info.rank = rankRequested;
info.singular_values = singularValues(:)';
info.normalized_gap = normalizedGap;
info.pca_seed = opts.paper.paired_hog_pca_seed;
info.used_extract_hog_features = hasHOG;
info.used_parallel_loop = useParallel;
info.uses_ground_truth = false;
info.cache_hit = false;
end

function [scores,singularValues] = fixed_randomized_pca(X,r,seed)
oversampling = 20;
sketchRank = min(size(X,2),r+oversampling);
stream = RandStream('mt19937ar','Seed',seed);
omega = randn(stream,size(X,2),sketchRank,'single');
sketch = X*omega;
for iteration = 1:2
    [Q,~] = qr(sketch,0);
    sketch = X*(X'*Q);
end
[Q,~] = qr(sketch,0);
smallMatrix = Q'*X;
[left,S,~] = svd(smallMatrix,'econ');
singularValues = double(diag(S));
scores = Q*left(:,1:r)*S(1:r,1:r);
end

function features = fixed_sobel_histograms( ...
        images,side,cellSize,binCount)
cellsDown = side/cellSize(1);
cellsAcross = side/cellSize(2);
features = zeros(size(images,1), ...
    cellsDown*cellsAcross*binCount,'single');
sobelX = single([1 0 -1;2 0 -2;1 0 -1]);
sobelY = sobelX';
for i = 1:size(images,1)
    image = reshape(images(i,:),side,side);
    gx = conv2(image,sobelX,'same');
    gy = conv2(image,sobelY,'same');
    magnitude = hypot(gx,gy);
    angle = mod(atan2(gy,gx),pi);
    row = zeros(1,size(features,2),'single');
    offset = 0;
    for x = 1:cellSize(1):side
        for y = 1:cellSize(2):side
            magCell = magnitude(x:x+cellSize(1)-1, ...
                y:y+cellSize(2)-1);
            angCell = angle(x:x+cellSize(1)-1, ...
                y:y+cellSize(2)-1);
            bins = min(binCount,floor(angCell/(pi/binCount))+1);
            for b = 1:binCount
                row(offset+b) = sum(magCell(bins==b),'all');
            end
            offset = offset+binCount;
        end
    end
    features(i,:) = row/max(norm(row),sqrt(eps('single')));
end
end
