function K = rbf_kernel_fixed(A,B,scale)

if ~(isscalar(scale) && isfinite(scale) && scale > 0)
    error('BCMKC:InvalidKernelScale','RBF scale must be finite and positive.');
end
aa = sum(A.^2,2);
bb = sum(B.^2,2)';
d2 = max(0,bsxfun(@plus,aa,bb) - 2*(A*B'));
K = exp(-d2/scale);
K(~isfinite(K)) = 0;
end

