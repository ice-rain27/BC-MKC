function [Xn,stats] = preprocess_view(X,opts)

if ~isnumeric(X) || ~ismatrix(X) || isempty(X)
    error('BCMKC:InvalidView','Every view must be a nonempty numeric matrix.');
end
Xn = double(X);
if any(~isfinite(Xn(:)))
    error('BCMKC:NonFiniteView','Input views may not contain NaN or Inf.');
end

stats.mean = zeros(1,size(Xn,2));
stats.scale = ones(1,size(Xn,2));
if opts.kernel.standardize
    stats.mean = mean(Xn,1);
    Xn = bsxfun(@minus,Xn,stats.mean);
    stats.scale = sqrt(mean(Xn.^2,1));
    stats.scale(stats.scale < sqrt(eps)) = 1;
    Xn = bsxfun(@rdivide,Xn,stats.scale);
end
end
