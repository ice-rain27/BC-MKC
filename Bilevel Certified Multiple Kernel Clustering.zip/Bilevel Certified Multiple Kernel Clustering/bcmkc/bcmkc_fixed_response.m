function [betaResponse,spectral,scores] = bcmkc_fixed_response( ...
    factors,beta,beta0,k,opts)

spectral = fused_topk(factors,beta,k,opts);
scores = kernel_alignment_scores(factors,spectral.U);
betaResponse = project_simplex(beta0 + scores/opts.inner.mu);
end

