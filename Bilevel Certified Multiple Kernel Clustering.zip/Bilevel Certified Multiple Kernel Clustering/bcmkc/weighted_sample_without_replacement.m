function idx = weighted_sample_without_replacement(weights,s)

w = double(weights(:));
n = numel(w);
s = min(max(round(s),0),n);
if s == 0
    idx = zeros(0,1);
    return;
end
w(~isfinite(w) | w < 0) = 0;
if sum(w) <= 0
    idx = randperm(n,s)';
    return;
end
keys = -inf(n,1);
positive = w > 0;
keys(positive) = log(max(rand(sum(positive),1),realmin))./w(positive);
[~,order] = sort(keys,'descend');
idx = order(1:s);
end
