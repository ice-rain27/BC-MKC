function scale = estimate_rbf_scale(X,opts)

n = size(X,1);
q = min(n,opts.kernel.bandwidth_sample_size);
idx = unique(round(linspace(1,n,q)));
Xs = X(idx,:);
sq = sum(Xs.^2,2);
d2 = max(0,bsxfun(@plus,sq,sq') - 2*(Xs*Xs'));
mask = triu(true(size(d2)),1) & d2 > 0 & isfinite(d2);
values = d2(mask);
if isempty(values)
    base = 1;
else
    base = median(values);
end
scale = max(opts.kernel.minimum_scale, ...
    opts.kernel.bandwidth_multiplier * base);
end

