function [U,values] = paper_truncated_left_space(block,rankRequested)

if ~isa(block,'double')
    block = double(block);
end

rankRequested = min([rankRequested,size(block,1),size(block,2)]);
if rankRequested < 1
    error('BCMKC:InvalidLeftSpaceRank','rankRequested must be positive.');
end
if min(size(block)) <= max(4*rankRequested,64)
    [left,S,~] = svd(block,'econ');
    values = diag(S);
    U = left(:,1:rankRequested);
    values = values(1:rankRequested);
else
    svdOptions.tol = 1e-9;
    svdOptions.maxit = 1000;
    previousState = rng;
    rng(104729,'twister');
    try
        [left,S,~,flag] = svds( ...
            block,rankRequested,'largest',svdOptions);
    catch exception
        rng(previousState);
        rethrow(exception)
    end
    rng(previousState);
    if flag ~= 0
        error('BCMKC:LeftSpaceSVD', ...
            'The truncated left-space SVD did not converge.');
    end
    [values,order] = sort(real(diag(S)),'descend');
    U = real(left(:,order));
end
[U,~] = qr(U,0);
end
