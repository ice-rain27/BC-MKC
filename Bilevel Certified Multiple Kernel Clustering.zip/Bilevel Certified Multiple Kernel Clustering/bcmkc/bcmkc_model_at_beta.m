function model = bcmkc_model_at_beta(factors,beta,beta0,k,opts)

beta = project_simplex(beta);
beta0 = project_simplex(beta0);
spectral = fused_topk(factors,beta,k,opts);
scores = kernel_alignment_scores(factors,spectral.U);
response = project_simplex(beta0+scores/opts.inner.mu);

model.beta = beta;
model.beta0 = beta0;
model.U = spectral.U;
model.lambda = spectral.lambda;
model.eigengap = spectral.eigengap;
model.eig_residual = spectral.eig_residual;
model.eigs_flag = spectral.eigs_flag;
model.alignment = scores;
model.fixed_point_residual = norm(beta-response);
model.objective = -beta'*scores + 0.5*opts.inner.mu*norm(beta-beta0)^2;
model.k = k;
model.mu = opts.inner.mu;
end

