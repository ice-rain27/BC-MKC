function [factor,info] = build_hierarchical_stable_consensus( ...
    X,k,spectralRank,anchorCounts,seed,opts)

X = X(:);
n = size(X{1},1);
viewCount = numel(X);
anchorCounts = unique(round(double(anchorCounts(:)')),'stable');
if isempty(anchorCounts) || any(anchorCounts < spectralRank) || ...
        any(anchorCounts > n)
    error('BCMKC:InvalidHierarchicalAnchors', ...
        'Hierarchical anchor counts must lie in [spectralRank,n].');
end

configCount = numel(anchorCounts);
viewBases = cell(configCount,viewCount);
landmarks = cell(configCount,viewCount);
spectralSeparation = zeros(configCount,viewCount);
singularValues = cell(configCount,viewCount);
for b = 1:configCount
    rng(seed+104729*(b-1),'twister');
    for v = 1:viewCount
        [idx,crossKernel] = recursiveNystrom_kernel( ...
            X{v},anchorCounts(b),0);
        landmarks{b,v} = idx;
        [viewBases{b,v},values] = truncated_left_basis( ...
            crossKernel,spectralRank,opts);
        singularValues{b,v} = values;
        spectralSeparation(b,v) = normalized_gap(values,spectralRank);
        clear crossKernel
    end
end

flatBases = zeros(n,spectralRank,configCount*viewCount);
flatView = zeros(configCount*viewCount,1);
component = 0;
for b = 1:configCount
    for v = 1:viewCount
        component = component+1;
        flatBases(:,:,component) = viewBases{b,v};
        flatView(component) = v;
    end
end
[flatAffinity,affinityMode] = projector_affinity( ...
    flatBases,opts.paper.stability_probe_count, ...
    opts.paper.stability_probe_seed);

viewStability = ones(viewCount,1);
viewCentrality = ones(viewCount,1);
for v = 1:viewCount
    own = find(flatView==v);
    other = find(flatView~=v);
    if numel(own) > 1
        block = flatAffinity(own,own);
        viewStability(v) = median(block(triu(true(size(block)),1)));
    end
    if ~isempty(other)
        block = flatAffinity(own,other);
        viewCentrality(v) = median(block(:));
    end
end
viewGap = median(spectralSeparation,1)';
gapFactor = relative_gap_factor(viewGap);
rawViewReliability = max(viewCentrality,eps) .* ...
    sqrt(max(viewStability,eps)) .* gapFactor;
viewWeights = floor_mixed_weights(rawViewReliability, ...
    opts.paper.reliability_data_fraction);

configBases = zeros(n,spectralRank,configCount);
configGaps = zeros(configCount,1);
for b = 1:configCount
    stack = zeros(n,spectralRank,viewCount);
    for v = 1:viewCount
        stack(:,:,v) = viewBases{b,v};
    end
    [configBases(:,:,b),configGaps(b)] = ...
        paper_subspace_barycenter(stack,viewWeights,spectralRank);
end
clear flatBases viewBases

if configCount == 1
    configAffinity = 1;
    configWeights = 1;
else
    [configAffinity,~] = projector_affinity( ...
        configBases,opts.paper.stability_probe_count, ...
        opts.paper.stability_probe_seed+1);
    rawConfigReliability = ...
        (sum(configAffinity,2)-1)/max(configCount-1,1);
    rawConfigReliability = max(rawConfigReliability,eps) .* ...
        relative_gap_factor(configGaps);
    configWeights = floor_mixed_weights(rawConfigReliability, ...
        opts.paper.reliability_data_fraction);
end
[robustU,barycenterGap] = paper_subspace_barycenter( ...
    configBases,configWeights,spectralRank);

factor = robustU/sqrt(spectralRank);
factor = factor/max(norm(factor,'fro'),sqrt(eps));
info.robust_embedding = robustU;
info.components = configBases;
info.component_names = arrayfun(@(a) sprintf('anchors_%d',a), ...
    anchorCounts(:),'UniformOutput',false);
info.component_weights = configWeights(:);
info.landmarks = landmarks;
info.barycenter_gap = barycenterGap;
info.view_weights = viewWeights;
info.view_stability = viewStability;
info.view_centrality = viewCentrality;
info.view_spectral_separation = viewGap;
info.view_affinity = flatAffinity;
info.config_affinity = configAffinity;
info.config_gaps = configGaps;
info.singular_values = singularValues;
info.affinity_mode = affinityMode;
info.stability_probe_seed = opts.paper.stability_probe_seed;
info.stability_probe_count = opts.paper.stability_probe_count;
info.anchor_counts = anchorCounts;
info.seed = seed;
info.uses_ground_truth = false;
info.view_order_invariant = true;
info.fixed_component_bank = true;
info.fixed_component_weights = true;
end

function [U,values] = truncated_left_basis(K,r,opts)
requested = min(r+1,min(size(K)));
if requested < r
    error('BCMKC:HierarchicalRank', ...
        'A cross-kernel cannot support spectral rank %d.',r);
end
if requested >= 0.6*min(size(K))
    [left,S,~] = svd(K,'econ');
    values = diag(S);
    U = left(:,1:r);
    values = values(1:min(numel(values),r+1));
else
    svdOpts.tol = opts.inner.eigs_tol;
    svdOpts.maxit = opts.inner.eigs_maxit;
    [left,S,~,flag] = svds(K,requested,'largest',svdOpts);
    if flag ~= 0
        error('BCMKC:HierarchicalSVD', ...
            'The truncated cross-kernel SVD did not converge.');
    end
    [values,order] = sort(diag(S),'descend');
    left = real(left(:,order));
    U = left(:,1:r);
end
[U,~] = qr(U,0);
end

function value = normalized_gap(values,r)
if numel(values) > r
    value = max(0,values(r)^2-values(r+1)^2)/ ...
        max(values(1)^2,eps);
else
    value = max(values(r)^2,eps)/max(values(1)^2,eps);
end
end

function factor = relative_gap_factor(gaps)
positive = gaps(isfinite(gaps) & gaps > 0);
if isempty(positive)
    factor = ones(size(gaps));
    return;
end
scale = median(positive);
factor = sqrt(max(gaps,0)/max(scale,eps));
factor = min(2,max(0.5,factor));
end

function weights = floor_mixed_weights(reliability,dataFraction)
reliability = max(double(reliability(:)),0);
if ~isfinite(sum(reliability)) || sum(reliability) <= 0
    reliability = ones(size(reliability));
end
dataFraction = min(max(double(dataFraction),0),1);
dataWeights = reliability/sum(reliability);
weights = (1-dataFraction)/numel(reliability) + dataFraction*dataWeights;
weights = weights/sum(weights);
end

function [affinity,mode] = projector_affinity(components,probeCount,probeSeed)
count = size(components,3);
r = size(components,2);
n = size(components,1);
affinity = eye(count);
if r <= 48
    mode = 'exact';
    for a = 1:count
        for b = a+1:count
            value = norm(components(:,:,a)'*components(:,:,b),'fro')^2/r;
            affinity(a,b) = min(1,max(0,value));
            affinity(b,a) = affinity(a,b);
        end
    end
    return;
end

mode = 'rademacher_probe';
state = rng;
restoreState = onCleanup(@() rng(state));
rng(probeSeed,'twister');
omega = 2*double(rand(n,probeCount) >= 0.5)-1;
projected = cell(count,1);
for a = 1:count
    U = components(:,:,a);
    projected{a} = U*(U'*omega);
end
clear omega
for a = 1:count
    for b = a+1:count
        value = sum(projected{a}(:).*projected{b}(:))/(probeCount*r);
        affinity(a,b) = min(1,max(0,value));
        affinity(b,a) = affinity(a,b);
    end
end
clear restoreState
end
