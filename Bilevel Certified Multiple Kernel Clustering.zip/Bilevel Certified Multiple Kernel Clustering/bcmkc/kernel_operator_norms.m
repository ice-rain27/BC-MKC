function [opNorms,froNorms] = kernel_operator_norms(factors)

m = numel(factors);
opNorms = zeros(m,1);
froNorms = zeros(m,1);
for v = 1:m
    G = factors{v}'*factors{v};
    G = (G+G')/2;
    opNorms(v) = max(real(eig(G)));
    froNorms(v) = norm(G,'fro');
end
end
