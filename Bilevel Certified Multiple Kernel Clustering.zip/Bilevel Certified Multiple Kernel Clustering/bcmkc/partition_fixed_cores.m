function [labels,scores,margins] = partition_fixed_cores(U,core)

[scores,~] = fixed_core_scores(U,core);
[best,labels] = max(scores,[],2);
if size(scores,2) == 1
    margins = inf(size(labels));
else
    competitor = scores;
    competitor(sub2ind(size(scores),(1:size(scores,1))',labels)) = -inf;
    second = max(competitor,[],2);
    margins = best-second;
end
end
