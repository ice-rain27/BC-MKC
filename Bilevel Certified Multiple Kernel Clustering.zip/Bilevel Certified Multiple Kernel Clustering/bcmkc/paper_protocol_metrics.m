function report = paper_protocol_metrics(U,Y,k,outerIterations,replicates,protocolSeed)

if nargin < 4
    outerIterations = 50;
end
if nargin < 5
    replicates = 10;
end
if nargin < 6 || isempty(protocolSeed)
    protocolSeed = 0;
end
if ~isnumeric(U) || ~ismatrix(U) || isempty(U) || any(~isfinite(U(:)))
    error('BCMKC:InvalidProtocolEmbedding', ...
        'U must be a nonempty finite numeric matrix.');
end
Y = Y(:);
if ~isnumeric(Y) || numel(Y) ~= size(U,1) || any(~isfinite(Y))
    error('BCMKC:InvalidProtocolLabels', ...
        'Y must contain one finite numeric label per row of U.');
end
if ~(isscalar(k) && isfinite(k) && k == floor(k) && ...
        k >= 1 && k < size(U,1))
    error('BCMKC:InvalidProtocolClusterCount', ...
        'k must be an integer in [1,n-1].');
end
if ~(isscalar(outerIterations) && isfinite(outerIterations) && ...
        outerIterations == floor(outerIterations) && outerIterations >= 1)
    error('BCMKC:InvalidProtocolIterations', ...
        'outerIterations must be a positive integer.');
end
if ~(isscalar(replicates) && isfinite(replicates) && ...
        replicates == floor(replicates) && replicates >= 1)
    error('BCMKC:InvalidProtocolReplicates', ...
        'replicates must be a positive integer.');
end
if ~(isscalar(protocolSeed) && isfinite(protocolSeed) && ...
        protocolSeed == round(protocolSeed) && protocolSeed >= 0 && ...
        protocolSeed < 2^32)
    error('BCMKC:InvalidProtocolSeed', ...
        'protocolSeed must be an integer in [0,2^32-1].');
end
previousState = rng;
restoreState = onCleanup(@() rng(previousState));
rng(protocolSeed,'twister');
embedding = U./max(repmat(sqrt(sum(U.^2,2)),1,size(U,2)),eps);
values = zeros(outerIterations,4);
for iter = 1:outerIterations
    labels = litekmeans(embedding,k,'MaxIter',100,'Replicates',replicates);
    mapped = bestMap(Y,labels(:));
    values(iter,1) = mean(Y==mapped);
    values(iter,2) = MutualInfo(Y,mapped);
    values(iter,3) = purFuc(Y,mapped);
    values(iter,4) = adjrandindex(Y,mapped);
end
[maxima,selectedIteration] = max(values,[],1);
report.ACC = maxima(1);
report.NMI = maxima(2);
report.Purity = maxima(3);
report.ARI = maxima(4);
report.per_partition = values;
report.selected_iteration = selectedIteration;
report.outer_iterations = outerIterations;
report.replicates = replicates;
report.protocol_seed = protocolSeed;
report.rng_isolated = true;
report.total_initializations = outerIterations*replicates;
report.nmi_definition = 'I(Y;Z)/max(H(Y),H(Z))';
report.metricwise_maxima = true;
report.uses_ground_truth_for_metric_selection = true;
report.certifiable_as_one_partition = false;
end
