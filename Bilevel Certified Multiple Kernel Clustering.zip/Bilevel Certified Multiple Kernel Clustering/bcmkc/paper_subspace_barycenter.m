function [U,gap] = paper_subspace_barycenter(embeddings,weights,k)

count = size(embeddings,3);
weights = double(weights(:));
if numel(weights) ~= count || any(weights < 0) || sum(weights) <= 0
    error('BCMKC:InvalidBarycenterWeights','Invalid subspace weights.');
end
weights = weights/sum(weights);
active = find(weights > 0);
n = size(embeddings,1);
block = zeros(n,k*numel(active),'like',embeddings);
for position = 1:numel(active)
    q = active(position);
    columns = (position-1)*k+(1:k);
    block(:,columns) = sqrt(weights(q))*embeddings(:,:,q);
end

requested = min(k+1,min(size(block)));
if requested < k
    error('BCMKC:BarycenterRank', ...
        'The weighted component bank cannot support rank %d.',k);
end
if min(size(block)) <= max(4*k,64)
    [left,values,~] = svd(block,'econ');
    spectrum = diag(values).^2;
else
    svdOpts.tol = 1e-9;
    svdOpts.maxit = 1000;
    [left,values,~,flag] = svds(block,requested,'largest',svdOpts);
    if flag ~= 0
        error('BCMKC:BarycenterSVD', ...
            'The truncated barycenter SVD did not converge.');
    end
    [singularValues,order] = sort(diag(values),'descend');
    left = real(left(:,order));
    spectrum = singularValues.^2;
end
U = left(:,1:k);
clear block
if numel(spectrum) > k
    gap = spectrum(k)-spectrum(k+1);
else
    gap = inf;
end
end
