function [KH,landmarks] = paper_build_cross_kernels(X,anchorCount,seed)

if exist('datasample','file') ~= 2
    error('BCMKC:KernelDependency', ...
        ['Paper-compatible RLS sampling requires datasample from the ', ...
        'Statistics and Machine Learning Toolbox.']);
end
X = X(:);
viewCount = numel(X);
n = size(X{1},1);
anchorCount = min(anchorCount,n);
KH = zeros(n,anchorCount,viewCount);
landmarks = zeros(viewCount,anchorCount);
rng(seed,'twister');
for v = 1:viewCount
    if size(X{v},1) ~= n
        error('BCMKC:ViewSizeMismatch','All views must contain the same samples.');
    end
    [idx,crossKernel] = recursiveNystrom_kernel(X{v},anchorCount,0);
    landmarks(v,:) = idx;
    KH(:,:,v) = crossKernel;
end
end
