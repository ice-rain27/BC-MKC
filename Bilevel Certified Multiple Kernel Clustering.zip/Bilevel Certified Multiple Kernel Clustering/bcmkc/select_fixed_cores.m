function core = select_fixed_cores(U,k,opts)

embedding = row_normalize(U);
[initialLabels,centers,objective] = deterministic_kmeans( ...
    embedding,k,opts.discretizer);
n = size(U,1);
indices = cell(k,1);
sizes = zeros(k,1);

for c = 1:k
    members = find(initialLabels==c);
    distance = sum(bsxfun(@minus,embedding(members,:),centers(c,:)).^2,2);
    [~,order] = sortrows([distance,members],[1,2]);
    count = max(opts.discretizer.core_min, ...
        ceil(opts.discretizer.core_fraction*numel(members)));
    count = min([count,numel(members),opts.discretizer.core_max]);
    chosen = members(order(1:count));
    indices{c} = chosen;
    sizes(c) = count;
end

rowIndex = vertcat(indices{:});
columnIndex = repelem((1:k)',sizes);
values = 1./repelem(sizes,sizes);
A = sparse(rowIndex,columnIndex,values,n,k);

core.A = A;
core.indices = indices;
core.sizes = sizes;
core.initial_labels = initialLabels;
core.initial_centers = centers;
core.initial_objective = objective;
[core.reference_labels,~,core.reference_margins] = ...
    partition_fixed_cores(U,core);
end
