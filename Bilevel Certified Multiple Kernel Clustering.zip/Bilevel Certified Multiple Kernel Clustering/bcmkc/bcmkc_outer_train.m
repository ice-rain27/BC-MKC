function [model,core,history] = bcmkc_outer_train( ...
    factors,spectralRank,clusterCount,opts)

if nargin < 4
    opts = clusterCount;
    clusterCount = spectralRank;
end

m = numel(factors);
if isempty(opts.outer.initial_prior)
    beta0 = ones(m,1)/m;
else
    beta0 = project_simplex(opts.outer.initial_prior);
    if numel(beta0) ~= m
        error('BCMKC:InitialPriorDimension', ...
            'outer.initial_prior must have one value per kernel factor.');
    end
end
theta = log(max(beta0,realmin));
theta = theta-mean(theta);
[model,innerHistory] = bcmkc_inner(factors,spectralRank,beta0,opts);
core = select_fixed_cores(model.U,clusterCount,opts);
[opNorms,froNorms] = kernel_operator_norms(factors);
baseGeometry.operator_norms = opNorms;
baseGeometry.frobenius_norms = froNorms;
baseGeometry.kappa = norm(opNorms,2);
baseGeometry.b = norm(froNorms,2)/opts.inner.mu;
[currentValue,currentComponents] = bcmkc_proxy( ...
    model,factors,core,beta0,opts,baseGeometry);

history = struct([]);
completed = 0;
for iter = 1:opts.outer.max_iter
    completed = iter;
    record = struct();
    [gradient,diagnostic] = implicit_hypergradient( ...
        factors,spectralRank,theta,model,core,baseGeometry,opts);
    record.iteration = iter;
    record.proxy_before = currentValue;
    record.components_before = currentComponents;
    record.beta0_before = beta0;
    record.beta_before = model.beta;
    record.implicit_gradient_valid = diagnostic.valid;
    record.implicit_diagnostic = diagnostic;
    record.accepted = false;
    record.step = 0;
    record.proxy_after = currentValue;
    record.beta0_after = beta0;
    record.beta_after = model.beta;

    if ~diagnostic.valid || norm(gradient) <= eps
        history = append_record(history,record);
        break;
    end

    direction = gradient/max(norm(gradient),1);
    step = opts.outer.step;
    accepted = false;
    while step >= opts.outer.min_step
        candidateTheta = theta+step*direction;
        candidateTheta = candidateTheta-mean(candidateTheta);
        candidateBeta0 = softmax_simplex(candidateTheta);
        [candidateModel,~] = bcmkc_inner( ...
            factors,spectralRank,candidateBeta0,opts);
        candidateValue = bcmkc_proxy( ...
            candidateModel,factors,core,candidateBeta0,opts,baseGeometry);
        if isfinite(candidateValue) && candidateValue > currentValue+1e-10
            theta = candidateTheta;
            beta0 = candidateBeta0;
            model = candidateModel;
            currentValue = candidateValue;
            [~,currentComponents] = bcmkc_proxy( ...
                model,factors,core,beta0,opts,baseGeometry);
            accepted = true;
            break;
        end
        step = step/2;
    end

    record.accepted = accepted;
    record.step = step;
    record.proxy_after = currentValue;
    record.beta0_after = beta0;
    record.beta_after = model.beta;
    history = append_record(history,record);
    if ~accepted
        break;
    end
end

if completed == 0
    history = struct('iteration',{},'proxy_before',{},'proxy_after',{});
else
    history = history(1:completed);
end
model.beta0 = beta0;
model.outer_proxy = currentValue;
model.outer_components = currentComponents;
model.initial_inner_history = innerHistory;
model.spectral_rank = spectralRank;
model.cluster_count = clusterCount;
end

function history = append_record(history,record)
if isempty(history)
    history = record;
else
    history(end+1,1) = record;
end
end
