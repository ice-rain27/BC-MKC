function orders = paper_view_orders(viewCount,maxOrders)

if factorial(viewCount) <= maxOrders
    orders = perms(1:viewCount);
    canonical = find(all(orders == repmat(1:viewCount,size(orders,1),1),2),1);
    orders([1,canonical],:) = orders([canonical,1],:);
    return;
end

orders = zeros(viewCount+2,viewCount);
orders(1,:) = 1:viewCount;
orders(2,:) = viewCount:-1:1;
for shift = 1:viewCount
    orders(shift+2,:) = circshift(1:viewCount,[0,shift]);
end
orders = unique(orders,'rows','stable');
orders = orders(1:min(size(orders,1),maxOrders),:);
end
