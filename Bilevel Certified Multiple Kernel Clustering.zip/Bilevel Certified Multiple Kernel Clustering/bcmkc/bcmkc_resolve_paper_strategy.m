function strategy = bcmkc_resolve_paper_strategy( ...
        sampleCount,viewCount,clusterCount,baseAnchors,opts,viewDimensions)

strategy = lower(char(opts.paper.strategy));
if ~strcmp(strategy,'auto')
    return
end
if nargin < 6
    viewDimensions = [];
end

if clusterCount >= opts.paper.robust_direct_k_threshold
    strategy = 'robust_direct_barycenter';
elseif paired_flat_images(sampleCount,viewCount,viewDimensions,opts)
    strategy = 'paired_image_hog';
elseif sampleCount >= opts.paper.trimmed_cross_n_threshold && ...
        viewCount >= opts.paper.trimmed_cross_min_views
    strategy = 'trimmed_cross_fusion';
elseif opts.paper.hierarchical_auto && ...
        (sampleCount >= opts.paper.hierarchical_n_threshold || ...
        clusterCount >= opts.paper.hierarchical_k_threshold)
    strategy = 'hierarchical_stability';
elseif viewCount <= 2 && ...
        sampleCount <= opts.paper.multiresolution_n_ratio*baseAnchors
    strategy = 'overcomplete_multiscale';
elseif viewCount >= opts.paper.many_view_threshold
    strategy = 'scalable_landmark_bagging';
elseif sampleCount >= opts.paper.large_scale_n_threshold
    strategy = 'scalable_order_multiscale';
else
    strategy = 'order_symmetrization';
end
end

function matched = paired_flat_images(sampleCount,viewCount,dimensions,opts)
matched = false;
if sampleCount < opts.paper.paired_hog_n_threshold || ...
        viewCount ~= 2 || numel(dimensions) ~= 2 || ...
        dimensions(1) ~= dimensions(2)
    return
end
side = sqrt(double(dimensions(1)));
matched = abs(side-round(side)) < 10*eps(max(side,1)) && ...
    round(side) >= opts.paper.paired_hog_min_side;
end
