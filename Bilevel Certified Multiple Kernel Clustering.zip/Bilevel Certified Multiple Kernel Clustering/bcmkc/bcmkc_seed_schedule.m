function schedule = bcmkc_seed_schedule(runCount,opts)

if nargin < 1 || isempty(runCount)
    runCount = 1;
end
if nargin < 2 || isempty(opts)
    opts = bcmkc_default_options();
end
if ~isscalar(runCount) || ~isfinite(runCount) || runCount < 1 || ...
        runCount ~= floor(runCount)
    error('BCMKC:InvalidRunCount','runCount must be a positive integer.');
end

modelBase = field_or(opts,'seed',5489);
paper = field_or(opts,'paper',struct());
paperBase = field_or(paper,'base_seed',modelBase);
baggingBase = field_or(paper,'bagging_seeds',[101,509,2027,4099]);
baggingBase = double(baggingBase(:)');
overcompleteBase = field_or(paper,'overcomplete_seeds',baggingBase);
overcompleteBase = double(overcompleteBase(:)');
discretizer = field_or(opts,'discretizer',struct());
discretizerBase = field_or(discretizer,'seed',20260823);
protocolBase = field_or(paper,'protocol_seed',5489);

template = struct('run_index',0,'model_seed',0,'paper_base_seed',0, ...
    'paper_bagging_seeds',[],'paper_overcomplete_seeds',[], ...
    'discretizer_seed',0,'protocol_seed',0);
schedule = repmat(template,runCount,1);
for r = 1:runCount
    offset = (r-1)*104729;
    schedule(r).run_index = r;
    schedule(r).model_seed = valid_seed(modelBase + offset);
    schedule(r).paper_base_seed = valid_seed(paperBase + 3*offset);
    schedule(r).paper_bagging_seeds = ...
        arrayfun(@(s) valid_seed(s + 5*offset),baggingBase);
    schedule(r).paper_overcomplete_seeds = ...
        arrayfun(@(s) valid_seed(s + 13*offset),overcompleteBase);
    schedule(r).discretizer_seed = ...
        valid_seed(discretizerBase + 7*offset);
    schedule(r).protocol_seed = valid_seed(protocolBase + 11*offset);
end
end

function value = field_or(s,name,fallback)
if isstruct(s) && isfield(s,name) && ~isempty(s.(name))
    value = s.(name);
else
    value = fallback;
end
end

function seed = valid_seed(value)
if ~(isscalar(value) && isfinite(value) && value == round(value))
    error('BCMKC:InvalidSeed', ...
        'Every seed must be a finite integer scalar.');
end
modulus = 2^32;
seed = mod(round(double(value)),modulus);
if seed < 0
    seed = seed + modulus;
end
end
