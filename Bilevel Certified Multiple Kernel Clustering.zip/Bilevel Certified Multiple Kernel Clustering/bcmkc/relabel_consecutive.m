function labels = relabel_consecutive(labels)

labels = labels(:);
[~,~,labels] = unique(labels,'sorted');
end

