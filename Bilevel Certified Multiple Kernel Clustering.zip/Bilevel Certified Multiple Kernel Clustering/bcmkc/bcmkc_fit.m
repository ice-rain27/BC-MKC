function [result,cache] = bcmkc_fit(X,k,userOptions)

opts = merge_options(bcmkc_default_options(),userOptions);
rng(opts.seed,'twister');
usesStabilizedPaper = opts.kernel.include_incremental_consensus && ...
    opts.paper.enabled && strcmpi(opts.kernel.consensus_mode,'stabilized_paper');
retainProcessedViews = ~usesStabilizedPaper || ...
    opts.evaluation.retain_processed_views;
[factors,nystromInfo,processedViews] = build_nystrom_factors( ...
    X,opts,retainProcessedViews);

rankOpts = opts;
effectiveMultiplier = opts.spectral.rank_multiplier;
rankPolicy = 'global_multiplier';
if opts.paper.enabled
    strategy = bcmkc_resolve_paper_strategy(size(X{1},1),numel(X),k, ...
        min(opts.paper.base_landmarks,size(X{1},1)),opts, ...
        cellfun(@(z) size(z,2),X));
    switch strategy
        case 'scalable_landmark_bagging'
            effectiveMultiplier = opts.paper.many_view_rank_multiplier;
            rankPolicy = 'many_view_auto_multiplier';
        case 'robust_direct_barycenter'
            effectiveMultiplier = opts.paper.robust_direct_rank_multiplier;
            rankPolicy = 'robust_direct_multiplier';
        case 'trimmed_cross_fusion'
            effectiveMultiplier = opts.paper.trimmed_cross_rank_multiplier;
            rankPolicy = 'trimmed_cross_multiplier';
        case 'paired_image_hog'
            effectiveMultiplier = opts.paper.paired_hog_rank_multiplier;
            rankPolicy = 'paired_image_hog_multiplier';
    end
end
rankOpts.spectral.rank_multiplier = effectiveMultiplier;
[spectralRank,spectralInfo] = bcmkc_resolve_spectral_rank( ...
    k,size(X{1},1),factors,rankOpts);
spectralInfo.configured_multiplier = opts.spectral.rank_multiplier;
spectralInfo.effective_multiplier = effectiveMultiplier;
spectralInfo.policy = rankPolicy;
opts.spectral.configured_rank_multiplier = opts.spectral.rank_multiplier;
opts.spectral.effective_rank_multiplier = effectiveMultiplier;
opts.spectral.resolved_rank = spectralRank;
opts.spectral.rank_policy = rankPolicy;
if opts.kernel.projector_compression
    [factors,projectorInfo] = compress_to_projector_kernels( ...
        factors,spectralRank,opts);
else
    projectorInfo = [];
end
consensusCache = [];
factorNames = arrayfun(@(v) sprintf('view_%d',v), ...
    (1:numel(factors))','UniformOutput',false);
if opts.kernel.include_incremental_consensus
    if opts.paper.enabled && strcmpi(opts.kernel.consensus_mode,'stabilized_paper')
        [consensusFactor,consensusCache] = ...
            build_stabilized_paper_consensus(X,k,opts,spectralRank);
        consensusName = 'stabilized_paper_consensus';
    else
        error('BCMKC:MainExperimentOnly','Use the stabilized BC-MKC kernel bank.');
    end
    viewCount = numel(factors);
    factors{end+1,1} = consensusFactor;
    factorNames{end+1,1} = consensusName;
    if isempty(opts.outer.initial_prior)
        if isfield(consensusCache,'recommended_prior')
            consensusWeight = consensusCache.recommended_prior;
        else
            consensusWeight = opts.kernel.consensus_prior_weight;
        end
        consensusWeight = min(max(consensusWeight,0),1);
        opts.outer.initial_prior = [ones(viewCount,1)*(1-consensusWeight)/viewCount; ...
            consensusWeight];
    end
end
[factors,factorTraceInfo] = normalize_kernel_factors(factors);

if opts.outer.enabled && opts.outer.max_iter > 0
    [model,~,trainHistory] = bcmkc_outer_train( ...
        factors,spectralRank,k,opts);
else
    if isempty(opts.outer.initial_prior)
        beta0 = ones(numel(factors),1)/numel(factors);
    else
        beta0 = project_simplex(opts.outer.initial_prior);
        if numel(beta0) ~= numel(factors)
            error('BCMKC:InitialPriorDimension', ...
                'outer.initial_prior must have one value per kernel factor.');
        end
    end
    [model,innerHistory] = bcmkc_inner( ...
        factors,spectralRank,beta0,opts);
    trainHistory = struct('inner_history',innerHistory, ...
        'implicit_gradient_valid',false, ...
        'note','Outer certificate-aware learning disabled.');
end
model.spectral_rank = spectralRank;
model.cluster_count = k;

core = select_fixed_cores(model.U,k,opts);
if size(model.U,2) ~= spectralRank || size(core.A,2) ~= k
    error('BCMKC:SpectralDecoderDimensionMismatch', ...
        'The learned eigenspace or fixed-core decoder has an invalid dimension.');
end

[opNorms,froNorms] = kernel_operator_norms(factors);
model.kernel_operator_norms = opNorms;
model.kernel_frobenius_norms = froNorms;
[labels,scores,margins] = partition_fixed_cores(model.U,core);
if numel(unique(labels)) ~= k
    error('BCMKC:MissingOutputCluster', ...
        'The frozen decoder did not produce all %d requested clusters.',k);
end
certificate = bcmkc_certify( ...
    model,factors,core,opts.certificate.epsilon,opts);
certificate.spectral_rank = spectralRank;
certificate.cluster_count = k;
certificate.certified_eigenspace = 'top-r';
if isfield(certificate,'labels') && ~isequal(labels,certificate.labels)
    error('BCMKC:CertificateOutputMismatch', ...
        'The reported partition does not match the partition checked by the certificate.');
end

result.beta = model.beta;
result.beta0 = model.beta0;
result.U = model.U;
result.cluster_count = k;
result.spectral_rank = spectralRank;
result.spectral_policy = spectralInfo;
result.labels = labels;
if numel(labels) <= 5000
    result.coassignment = coassignment_matrix(labels);
else
    result.coassignment = [];
end
result.partition_scores = scores;
result.assignment_margins = margins;
result.core = core;
result.certificate = certificate;
result.inner = rmfield_if_present(model,{'U','initial_inner_history'});
result.nystrom_info = nystromInfo;
result.projector_kernel_info = projectorInfo;
result.factor_trace_info = factorTraceInfo;
result.factor_names = factorNames;
if ~isempty(consensusCache) && isfield(consensusCache,'protocol_embedding')
    result.paper_protocol_embedding = consensusCache.protocol_embedding;
    result.paper_protocol_embedding_source = ...
        consensusCache.protocol_embedding_source;
    result.paper_protocol_embedding_certified = ...
        consensusCache.protocol_embedding_certified;
else
    result.paper_protocol_embedding = [];
    result.paper_protocol_embedding_source = ...
        'learned top-r spectral embedding';
    result.paper_protocol_embedding_certified = true;
end
result.consensus_info = rmfield_if_present(consensusCache, ...
    {'robust_embedding','published_embedding','components', ...
    'protocol_embedding'});
resultOptions = opts;
if isfield(resultOptions.paper,'paired_hog_precomputed') && ...
        ~isempty(resultOptions.paper.paired_hog_precomputed)
    cached = resultOptions.paper.paired_hog_precomputed;
    resultOptions.paper.paired_hog_precomputed = struct( ...
        'reused',true,'sample_count',cached.sample_count, ...
        'feature_dimension',cached.feature_dimension, ...
        'rank',cached.rank);
end
result.options = resultOptions;

cache.factors = factors;
cache.nystrom_info = nystromInfo;
cache.processed_views = processedViews;
cache.consensus = consensusCache;
end

function value = rmfield_if_present(value,names)
for i = 1:numel(names)
    if isfield(value,names{i})
        value = rmfield(value,names{i});
    end
end
end
