function [gradient,diagnostic] = implicit_hypergradient( ...
    factors,k,theta,model,core,baseGeometry,opts)

m = numel(factors);
gradient = zeros(m,1);
diagnostic.valid = false;
diagnostic.reason = '';
diagnostic.rcond = 0;
diagnostic.active_set = model.beta > opts.outer.active_tolerance;

if m == 1
    diagnostic.valid = true;
    diagnostic.reason = 'Single-view problem has no weight-prior direction.';
    diagnostic.rcond = 1;
    return;
end
if any(model.beta <= opts.outer.active_tolerance)
    diagnostic.reason = 'Lower fixed point lies on a simplex boundary.';
    return;
end

T = null(ones(1,m));
r = size(T,2);
h = opts.outer.fd_step;
maxDirection = max(abs(T(:)));
h = min(h,0.2*min(model.beta)/max(maxDirection,eps));
if ~(isfinite(h) && h > 10*eps)
    diagnostic.reason = 'No safe finite-difference step inside the simplex.';
    return;
end

beta0 = softmax_simplex(theta);
[baseResponse,~,~] = bcmkc_fixed_response( ...
    factors,model.beta,beta0,k,opts);
active = baseResponse > opts.outer.active_tolerance;
Jbeta = zeros(r,r);
Jtheta = zeros(r,r);
gradLower = zeros(r,1);
gradDirect = zeros(r,1);

for j = 1:r
    direction = T(:,j);
    betaPlus = model.beta+h*direction;
    betaMinus = model.beta-h*direction;
    if any(betaPlus < 0) || any(betaMinus < 0)
        diagnostic.reason = 'Finite difference crossed a simplex face.';
        return;
    end

    plusModel = bcmkc_model_at_beta(factors,betaPlus,beta0,k,opts);
    minusModel = bcmkc_model_at_beta(factors,betaMinus,beta0,k,opts);
    plusResponse = project_simplex(beta0+plusModel.alignment/opts.inner.mu);
    minusResponse = project_simplex(beta0+minusModel.alignment/opts.inner.mu);
    if ~isequal(plusResponse>opts.outer.active_tolerance,active) || ...
            ~isequal(minusResponse>opts.outer.active_tolerance,active)
        diagnostic.reason = 'Simplex active set changes under beta perturbation.';
        return;
    end
    Jbeta(:,j) = T'*(plusResponse-minusResponse)/(2*h);
    plusValue = bcmkc_proxy(plusModel,factors,core,beta0,opts,baseGeometry);
    minusValue = bcmkc_proxy(minusModel,factors,core,beta0,opts,baseGeometry);
    gradLower(j) = (plusValue-minusValue)/(2*h);

    thetaPlus = theta+h*direction;
    thetaMinus = theta-h*direction;
    priorPlus = softmax_simplex(thetaPlus);
    priorMinus = softmax_simplex(thetaMinus);
    responsePlus = project_simplex(priorPlus+model.alignment/opts.inner.mu);
    responseMinus = project_simplex(priorMinus+model.alignment/opts.inner.mu);
    if ~isequal(responsePlus>opts.outer.active_tolerance,active) || ...
            ~isequal(responseMinus>opts.outer.active_tolerance,active)
        diagnostic.reason = 'Simplex active set changes under prior perturbation.';
        return;
    end
    Jtheta(:,j) = T'*(responsePlus-responseMinus)/(2*h);
    directPlus = bcmkc_proxy(model,factors,core,priorPlus,opts,baseGeometry);
    directMinus = bcmkc_proxy(model,factors,core,priorMinus,opts,baseGeometry);
    gradDirect(j) = (directPlus-directMinus)/(2*h);
end

system = eye(r)-Jbeta;
diagnostic.rcond = rcond(system);
if diagnostic.rcond < opts.outer.linear_system_rcond
    diagnostic.reason = 'Implicit fixed-point linear system is ill-conditioned.';
    return;
end

dBetaDTheta = system\Jtheta;
gradientTangent = dBetaDTheta'*gradLower + gradDirect;
gradient = T*gradientTangent;
gradient = gradient-mean(gradient);
diagnostic.valid = all(isfinite(gradient));
if diagnostic.valid
    diagnostic.reason = 'Implicit derivative verified on a stable active set.';
else
    diagnostic.reason = 'Implicit derivative contains non-finite values.';
end
diagnostic.Jbeta = Jbeta;
diagnostic.Jtheta = Jtheta;
end
