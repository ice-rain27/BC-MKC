function [rInd, C] = recursiveNystrom_kernel(X,s,accelerated_flag)


    [n,d] = size(X);

    if(~accelerated_flag)
        sLevel = s;
    else
        sLevel = ceil(sqrt((n*s + s^3)/(4*n)));
    end
    oversamp = log(sLevel);
    k = ceil(sLevel/(4*oversamp));
    nLevels = ceil(log(n/sLevel)/log(2));
    perm = randperm(n);

    lSize = zeros(1,nLevels+1);
    lSize(1) = n;
    for i = 2:nLevels+1
        lSize(i) = ceil(lSize(i-1)/2);
    end

    samp = 1:lSize(end);
    rInd = perm(samp);
    weights = ones(length(rInd),1);


    kDiag = ones(n,1);
    for l = nLevels:-1:1
        rIndCurr = perm(1:lSize(l));
        KS = create_kernel(X(rIndCurr,:),X(rInd,:));
        SKS = KS(samp,:);
        SKSn = size(SKS,1);

        if(k >= SKSn)
            lambda = 10e-6;
        else
            lambda = (sum(diag(SKS).*weights.^2) - sum(abs(real(eigs(@(x) (SKS*(x.*weights)).*weights, SKSn, k)))))/k;
        end
        lambda = max(lambda,1e-7);
        if(l ~= 1)
            R = inv(SKS + diag(lambda*weights.^(-2)));
            levs = min(1,oversamp*(1/lambda)*max(0,(kDiag(rIndCurr) - sum((KS*R).*KS,2))));
            samp = find(rand(1,lSize(l)) < levs');
            if(isempty(samp))
                levs(:) = sLevel/lSize(l);
                samp = randperm(lSize(l),sLevel);
            end
            weights = sqrt(1./(levs(samp)));

        else
            R = inv(SKS + diag(lambda*weights.^(-2)));
            levs = min(1,(1/lambda)*max(0,(kDiag(rIndCurr) - sum((KS*R).*KS,2))));
            samp = datasample(1:n,s,'Replace',false,'Weights',levs);
        end
        rInd = perm(samp);
    end


    C = create_kernel(X, X(rInd,:));
    SKS = C(rInd,:);
    W = inv(SKS+(10e-10)*eye(s,s));
end
